import { api } from './api.js';
import { refreshAll } from './state.js';
import { toast } from './toast.js';

const LABELS = {
  received: 'Received', in_kitchen: 'In Kitchen', packed: 'Packed', out_for_delivery: 'Out for Delivery', delivered: 'Delivered',
};

/** Runs an API action, refreshes data, and reports failures as toasts instead of throwing. */
async function perform(fn) {
  try {
    const result = await fn();
    await refreshAll();
    return result;
  } catch (err) {
    toast(err.message, { error: true });
    await refreshAll().catch(() => {});
    return null;
  }
}

export async function assignCourier(orderId, courierId) {
  const result = await perform(() => api.post(`/api/orders/${orderId}/assign`, { courierId }));
  if (result) toast(`Order #${orderId} assigned to ${result.order.courierName}.`);
}

export async function advanceOrder(order) {
  const result = await perform(() => api.post(`/api/orders/${order.id}/advance`));
  if (!result) return;
  const message = `Order #${order.id}: ${LABELS[result.from]} → ${LABELS[result.to]}.`;
  if (result.recommendation) {
    const rec = result.recommendation;
    toast(`${message} Recommended courier: ${rec.name} (Sector ${rec.zoneCode}).`, {
      action: { label: `Assign ${rec.name}`, onClick: () => assignCourier(order.id, rec.courierId) },
    });
  } else {
    toast(message);
  }
}

export async function unassignOrder(orderId) {
  const result = await perform(() => api.post(`/api/orders/${orderId}/unassign`));
  if (result) toast(`Courier removed from order #${orderId}.`);
}

export async function dispatchCourier(courier) {
  const result = await perform(() => api.post(`/api/couriers/${courier.id}/dispatch`));
  if (result) toast(`${courier.name} is out with ${result.dispatchedOrderIds.length} order(s): #${result.dispatchedOrderIds.join(', #')}.`);
}

export async function assignBatch(batch, courierId, courierName) {
  const result = await perform(() => api.post('/api/batches/assign', { orderIds: batch.readyOrderIds, courierId }));
  if (result) toast(`Batch ${batch.id}: ${result.assignedOrderIds.length} order(s) assigned to ${courierName}.`);
}
