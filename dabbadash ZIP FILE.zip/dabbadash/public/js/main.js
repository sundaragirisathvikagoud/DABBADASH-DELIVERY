import { api } from './api.js';
import { state, subscribe, refreshAll, loadMeta } from './state.js';
import { startRealtime } from './realtime.js';
import { toast } from './toast.js';
import { renderKpis } from './kpis.js';
import { renderBoard, renderBrandFilter, tickTimers } from './board.js';
import { renderDispatch, initPayoutForm } from './dispatch.js';
import { renderMap } from './map.js';
import { renderSms } from './smslog.js';
import { initNewOrder } from './neworder.js';

let activeView = 'board';

function showView(name) {
  activeView = name;
  document.querySelectorAll('.tab').forEach((tab) => {
    const on = tab.dataset.view === name;
    tab.classList.toggle('is-active', on);
    tab.setAttribute('aria-selected', String(on));
    tab.tabIndex = on ? 0 : -1;
  });
  ['board', 'dispatch', 'map', 'sms'].forEach((v) => { document.getElementById(`view-${v}`).hidden = v !== name; });
  renderActive(new Set(['orders', 'couriers', 'batches', 'sms']));
}

function renderActive(changed) {
  renderKpis();
  const touched = (...keys) => keys.some((k) => changed.has(k));
  if (activeView === 'board' && touched('orders', 'couriers')) renderBoard(() => showView('dispatch'));
  if (activeView === 'dispatch' && touched('orders', 'couriers', 'batches')) renderDispatch();
  if (activeView === 'map' && touched('orders', 'couriers')) renderMap();
  if (activeView === 'sms' && touched('sms')) renderSms();
  tickTimers();
}

function setConnection(mode) {
  const el = document.getElementById('conn');
  el.textContent = mode === 'live' ? 'Live' : 'Polling (3s)';
  el.classList.toggle('is-live', mode === 'live');
  el.classList.toggle('is-poll', mode !== 'live');
}

async function boot() {
  let me;
  try {
    me = await api.get('/api/auth/me');
  } catch {
    return; // api.js already redirected to the login page on 401
  }
  document.getElementById('username').textContent = me.user.username;
  await loadMeta();
  renderBrandFilter(() => renderActive(new Set(['orders'])));
  initNewOrder();
  initPayoutForm();

  subscribe(renderActive);
  document.querySelectorAll('.tab').forEach((tab) => tab.addEventListener('click', () => showView(tab.dataset.view)));
  document.querySelector('.tabs').addEventListener('keydown', (e) => {
    const tabs = [...document.querySelectorAll('.tab')];
    const i = tabs.indexOf(document.activeElement);
    if (i < 0 || !['ArrowRight', 'ArrowLeft'].includes(e.key)) return;
    const next = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
    next.focus();
    showView(next.dataset.view);
  });

  document.getElementById('logout').addEventListener('click', async () => {
    await api.post('/api/auth/logout').catch(() => {});
    window.location.replace('/login.html');
  });
  document.getElementById('btnSimulate').addEventListener('click', async () => {
    try {
      const { order } = await api.post('/api/orders/simulate');
      toast(`Incoming order #${order.id} from ${order.brand} (Sector ${order.zoneCode}).`);
      await refreshAll();
    } catch (err) { toast(err.message, { error: true }); }
  });
  document.getElementById('btnReset').addEventListener('click', async () => {
    if (!window.confirm('Reset all orders to the 15-order demo data set?')) return;
    try {
      await api.post('/api/demo/reset');
      toast('Demo data reset.');
      await refreshAll();
    } catch (err) { toast(err.message, { error: true }); }
  });

  await refreshAll();
  showView('board');
  setInterval(tickTimers, 1000);
  startRealtime({
    streamUrl: '/api/stream',
    onChange: () => refreshAll().catch(() => {}),
    onStatus: setConnection,
  });
}

boot().catch((err) => toast(err.message || 'Failed to start the dashboard', { error: true }));
