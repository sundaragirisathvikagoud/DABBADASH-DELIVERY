import { h, clear, money, mmss, itemSummary } from './util.js';
import { state, serverNow } from './state.js';
import { advanceOrder, assignCourier } from './actions.js';

const ACTION_LABEL = {
  received: 'Start cooking',
  in_kitchen: 'Mark packed',
  packed: 'Dispatch',
  out_for_delivery: 'Mark delivered',
};

function primaryAction(order, goToDispatch) {
  if (order.status === 'delivered') return null;
  if (order.status === 'packed' && !order.courierId) {
    const rec = order.recommendation;
    return h('div', { class: 'card-actions' },
      rec && h('button', { class: 'btn btn-small', type: 'button', onclick: () => assignCourier(order.id, rec.courierId) }, `Assign ${rec.name}`),
      h('button', { class: 'btn btn-small btn-ghost', type: 'button', onclick: goToDispatch }, 'Choose courier…'));
  }
  return h('div', { class: 'card-actions' },
    h('button', {
      class: `btn btn-small${order.status === 'out_for_delivery' ? ' btn-good' : ''}`, type: 'button',
      onclick: () => advanceOrder(order),
    }, ACTION_LABEL[order.status]));
}

function card(order, goToDispatch) {
  const since = order.status === 'delivered' ? null : order.statusSince;
  const node = h('article', {
    class: 'card',
    style: { '--brand': order.brandColor },
    dataset: { orderId: order.id, status: order.status, since: since ?? '' },
    'aria-label': `Order ${order.id}, ${order.brand}, ${order.statusLabel}`,
  },
  h('div', { class: 'card-head' },
    h('span', { class: 'order-id' }, `#${order.id}`),
    h('span', { class: 'brand-chip' }, order.brand),
    since != null && h('span', { class: 'timer', title: 'Time in this stage' }, '00:00')),
  h('span', { class: 'late-badge' }, `⚠ Over ${state.meta.bottleneckMinutes} min in kitchen`),
  h('p', { class: 'card-items' }, itemSummary(order.items)),
  h('div', { class: 'card-meta' },
    h('span', { class: 'zone-chip' }, `Sector ${order.zoneCode}`),
    h('span', {}, order.customerName),
    h('span', {}, money(order.total))),
  order.courierName && h('div', { class: 'courier-line' }, `🛵 ${order.courierName}`),
  order.recommendation && h('div', { class: 'reco-line' }, `Recommended: ${order.recommendation.name} (Sector ${order.recommendation.zoneCode})`),
  primaryAction(order, goToDispatch),
  h('div', { class: 'card-actions' },
    h('a', { href: `/track.html?t=${encodeURIComponent(order.trackingToken)}`, target: '_blank', rel: 'noopener noreferrer' }, 'Customer tracking view ↗')));
  return node;
}

export function renderBoard(goToDispatch) {
  const host = document.getElementById('board');
  const visible = state.orders.filter((o) => !state.brandFilter || o.brandId === state.brandFilter);
  clear(host);
  state.meta.statuses.forEach(({ key, label }) => {
    let list = visible.filter((o) => o.status === key);
    if (key === 'delivered') list = list.sort((a, b) => b.deliveredAt - a.deliveredAt).slice(0, 8);
    host.append(h('section', { class: 'column', 'aria-label': `${label} column` },
      h('div', { class: 'column-head' }, h('h3', {}, label), h('span', { class: 'count' }, list.length)),
      h('div', { class: 'column-body' },
        list.length ? list.map((o) => card(o, goToDispatch)) : h('div', { class: 'empty' }, 'No orders'))));
  });
  tickTimers();
}

/** Updates every visible stage timer and the flashing-red bottleneck state once per second. */
export function tickTimers() {
  const limit = state.meta.bottleneckMinutes * 60;
  document.querySelectorAll('.card[data-since]').forEach((el) => {
    if (!el.dataset.since) return;
    const seconds = (serverNow() - Number(el.dataset.since)) / 1000;
    const timer = el.querySelector('.timer');
    if (timer) timer.textContent = mmss(seconds);
    el.classList.toggle('is-bottleneck', el.dataset.status === 'in_kitchen' && seconds > limit);
  });
}

export function renderBrandFilter(onChange) {
  const host = document.getElementById('brandFilter');
  clear(host);
  const make = (label, id, color) => h('button', {
    class: 'chip', type: 'button', style: color ? { '--chip': color } : {},
    'aria-pressed': String(state.brandFilter === id),
    onclick: () => { state.brandFilter = id; renderBrandFilter(onChange); onChange(); },
  }, label);
  host.append(make('All brands', null, null), ...state.meta.brands.map((b) => make(b.name, b.id, b.color)));
}
