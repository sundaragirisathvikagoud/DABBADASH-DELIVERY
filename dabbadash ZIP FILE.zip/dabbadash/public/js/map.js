import { h, clear } from './util.js';
import { state } from './state.js';

/**
 * Interactive sector map. Uses Leaflet + OpenStreetMap tiles when the CDN is reachable;
 * otherwise falls back to a self-contained SVG map so the feature works fully offline.
 */
let leafletMap = null;
let layer = null;
let fitted = false;

const STATUS_COLOR = {
  received: '#64748b', in_kitchen: '#d97706', packed: '#7c3aed', out_for_delivery: '#2563eb',
};

function mapData() {
  return {
    kitchen: state.meta.kitchen,
    zones: state.meta.zones,
    orders: state.orders.filter((o) => o.status !== 'delivered'),
    couriers: state.couriers,
  };
}

function popupNode(title, lines) {
  return h('div', {}, h('strong', {}, title), ...lines.map((l) => h('div', {}, l)));
}

function renderLegend() {
  const host = clear(document.getElementById('mapLegend'));
  Object.entries(STATUS_COLOR).forEach(([key, color]) => {
    host.append(h('li', {}, h('span', { class: 'dot', style: { background: color } }), key.replace(/_/g, ' ')));
  });
  host.append(h('li', {}, '🍳 Kitchen'), h('li', {}, '🛵 Courier'), h('li', {}, 'Dashed circle = 2.5 km sector radius'));
}

function renderLeaflet(data) {
  const L = window.L;
  if (!leafletMap) {
    leafletMap = L.map('map').setView([data.kitchen.lat, data.kitchen.lng], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18, attribution: '&copy; OpenStreetMap contributors',
    }).addTo(leafletMap);
    layer = L.layerGroup().addTo(leafletMap);
  }
  layer.clearLayers();
  const emoji = (glyph) => L.divIcon({ className: 'pin-label', html: glyph, iconSize: [26, 26], iconAnchor: [13, 13] });

  data.zones.forEach((z) => {
    L.circle([z.lat, z.lng], { radius: state.meta.clusterRadiusKm * 1000, color: '#6366f1', weight: 1, dashArray: '6 6', fillOpacity: 0.05 })
      .bindPopup(popupNode(z.name, [])).addTo(layer);
  });
  L.marker([data.kitchen.lat, data.kitchen.lng], { icon: emoji('🍳') })
    .bindPopup(popupNode(data.kitchen.name, ['Shared commissary kitchen'])).addTo(layer);
  data.orders.forEach((o) => {
    L.circleMarker([o.lat, o.lng], { radius: 8, color: '#fff', weight: 2, fillColor: STATUS_COLOR[o.status], fillOpacity: 1 })
      .bindPopup(popupNode(`#${o.id} ${o.brand}`, [o.statusLabel, `Sector ${o.zoneCode}`, o.customerName])).addTo(layer);
  });
  data.couriers.filter((c) => c.active).forEach((c) => {
    L.marker([c.position.lat, c.position.lng], { icon: emoji('🛵') })
      .bindPopup(popupNode(c.name, [c.status.replace('_', ' '), `${c.load}/${c.capacity} orders`])).addTo(layer);
  });
  if (!fitted) {
    const points = [[data.kitchen.lat, data.kitchen.lng], ...data.zones.map((z) => [z.lat, z.lng])];
    leafletMap.fitBounds(points, { padding: [40, 40] });
    fitted = true;
  }
}

const SVG_NS = 'http://www.w3.org/2000/svg';
function svg(tag, attrs = {}, text) {
  const el = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, String(v)));
  if (text) el.textContent = text;
  return el;
}

function renderSvg(data) {
  const host = clear(document.getElementById('map'));
  const W = 900;
  const H = 540;
  const pts = [data.kitchen, ...data.zones, ...data.orders, ...data.couriers.map((c) => c.position)];
  const lats = pts.map((p) => p.lat);
  const lngs = pts.map((p) => p.lng);
  const pad = 0.02;
  const minLat = Math.min(...lats) - pad;
  const maxLat = Math.max(...lats) + pad;
  const minLng = Math.min(...lngs) - pad;
  const maxLng = Math.max(...lngs) + pad;
  const x = (lng) => ((lng - minLng) / (maxLng - minLng)) * W;
  const y = (lat) => H - ((lat - minLat) / (maxLat - minLat)) * H;
  const kmToPx = (km) => (km / 111.32 / (maxLng - minLng)) * W * 1.05;

  const root = svg('svg', { viewBox: `0 0 ${W} ${H}`, role: 'presentation' });
  root.append(svg('rect', { width: W, height: H, fill: '#e8efe9' }));
  data.zones.forEach((z) => {
    root.append(svg('circle', { cx: x(z.lng), cy: y(z.lat), r: kmToPx(state.meta.clusterRadiusKm), fill: '#6366f1', 'fill-opacity': 0.07, stroke: '#6366f1', 'stroke-dasharray': '6 6' }));
    root.append(svg('text', { x: x(z.lng), y: y(z.lat) - kmToPx(state.meta.clusterRadiusKm) - 6, 'text-anchor': 'middle', 'font-size': 14, 'font-weight': 700, fill: '#3730a3' }, z.name));
  });
  data.orders.forEach((o) => {
    const dot = svg('circle', { cx: x(o.lng), cy: y(o.lat), r: 8, fill: STATUS_COLOR[o.status], stroke: '#fff', 'stroke-width': 2 });
    dot.append(svg('title', {}, `#${o.id} ${o.brand} - ${o.statusLabel} (Sector ${o.zoneCode})`));
    root.append(dot);
  });
  root.append(svg('text', { x: x(data.kitchen.lng), y: y(data.kitchen.lat) + 8, 'text-anchor': 'middle', 'font-size': 26 }, '🍳'));
  data.couriers.filter((c) => c.active).forEach((c) => {
    root.append(svg('text', { x: x(c.position.lng), y: y(c.position.lat) + 8, 'text-anchor': 'middle', 'font-size': 24 }, '🛵'));
    root.append(svg('text', { x: x(c.position.lng), y: y(c.position.lat) + 24, 'text-anchor': 'middle', 'font-size': 11, 'font-weight': 700, fill: '#1c1917' }, c.name));
  });
  host.append(root);
}

export function renderMap() {
  const data = mapData();
  if (window.L) {
    renderLeaflet(data); // Leaflet owns the container once initialised
    setTimeout(() => leafletMap && leafletMap.invalidateSize(), 50);
  } else {
    renderSvg(data);
  }
  renderLegend();
}
