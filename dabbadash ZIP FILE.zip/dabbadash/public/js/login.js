const form = document.getElementById('loginForm');
const error = document.getElementById('loginError');
const submit = document.getElementById('loginSubmit');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  error.textContent = '';
  const username = form.elements.username.value.trim();
  const password = form.elements.password.value;
  if (!username || !password) {
    error.textContent = 'Enter your username and password.';
    return;
  }
  submit.disabled = true;
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      error.textContent = data.error || 'Sign in failed.';
      return;
    }
    window.location.replace('/');
  } catch {
    error.textContent = 'Cannot reach the server.';
  } finally {
    submit.disabled = false;
  }
});
