import { h, clear } from './util.js';
import { state } from './state.js';

function kpi(label, value, sub, cls = '') {
  return h('div', { class: `kpi ${cls}` },
    h('div', { class: 'kpi-label' }, label),
    h('div', { class: 'kpi-value' }, value),
    h('div', { class: 'kpi-sub' }, sub));
}

export function renderKpis() {
  const m = state.metrics;
  const host = document.getElementById('kpis');
  if (!m) return;
  clear(host).append(
    kpi('Active orders', m.activeOrders, `${m.counts.received} new · ${m.counts.in_kitchen} cooking`, 'is-active-kpi'),
    kpi('Avg prep time', m.avgPrepMinutes == null ? '–' : `${m.avgPrepMinutes} min`, 'kitchen time, last 50 packed', 'is-good'),
    kpi('In kitchen', m.inKitchen, 'received + cooking'),
    kpi('Pending dispatch', m.pendingDispatch, 'packed, no courier yet', m.pendingDispatch > 0 ? 'is-active-kpi' : ''),
    kpi('Dispatched', m.dispatched, `${m.delivered} delivered`),
    kpi('Couriers free', m.ridersAtKitchen, `${m.ridersOnDelivery} on delivery`),
    kpi('Bottlenecks', m.bottlenecks, `orders > ${m.bottleneckMinutes} min in kitchen`, m.bottlenecks > 0 ? 'is-alert' : ''),
  );
  const badge = document.getElementById('badge-dispatch');
  badge.hidden = m.pendingDispatch === 0;
  badge.textContent = String(m.pendingDispatch);
}
