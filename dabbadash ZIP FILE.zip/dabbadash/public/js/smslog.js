import { h, clear, clockTime } from './util.js';
import { state } from './state.js';

export function renderSms() {
  const host = clear(document.getElementById('smsLog'));
  if (!state.sms.length) host.append(h('p', { class: 'hint' }, 'No messages yet. Status changes trigger SMS tracking links automatically.'));
  state.sms.forEach((m) => {
    host.append(h('article', { class: 'sms' },
      h('div', { class: 'sms-meta' }, h('span', {}, `To ${m.to} · order #${m.orderId} · ${m.brand}`), h('span', {}, clockTime(m.createdAt))),
      h('p', {}, m.body),
      h('a', { href: m.link, target: '_blank', rel: 'noopener noreferrer' }, 'Open tracking page ↗')));
  });
}
