import { debounce } from './util.js';

/**
 * Keeps views in sync with the server using two mechanisms:
 *  1. Server-Sent Events push a nudge the instant any order changes (near-zero latency).
 *  2. A 3-second poll as a safety net, so the dashboard still works behind proxies that buffer SSE.
 * `onChange` is called to re-fetch; `onStatus('live' | 'poll')` drives the connection badge.
 */
export function startRealtime({ streamUrl, onChange, onStatus, pollMs = 3000 }) {
  const nudge = debounce(onChange, 120);
  let source = null;
  let live = false;

  function connect() {
    if (typeof EventSource === 'undefined') return onStatus('poll');
    source = new EventSource(streamUrl);
    source.addEventListener('hello', () => { live = true; onStatus('live'); });
    source.addEventListener('update', nudge);
    source.onerror = () => { live = false; onStatus('poll'); };
    return undefined;
  }

  connect();
  const timer = setInterval(() => {
    if (document.hidden) return;
    onChange();
    if (!live) onStatus('poll');
  }, pollMs);

  return () => {
    clearInterval(timer);
    if (source) source.close();
  };
}
