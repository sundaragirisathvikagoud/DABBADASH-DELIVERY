export class ApiError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

/** Thin fetch wrapper: JSON in/out, cookies sent automatically, 401 redirects to the login page. */
async function request(method, path, body) {
  const options = { method, headers: { Accept: 'application/json' }, credentials: 'same-origin' };
  if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  } else if (method !== 'GET') {
    options.headers['Content-Type'] = 'application/json';
    options.body = '{}';
  }
  let response;
  try {
    response = await fetch(path, options);
  } catch {
    throw new ApiError(0, 'Cannot reach the server. Check that it is running.');
  }
  let data = null;
  try {
    data = await response.json();
  } catch {
    /* non-JSON error page */
  }
  if (response.status === 401 && !path.startsWith('/api/auth/login') && !path.startsWith('/api/track/')) {
    window.location.replace('/login.html');
    throw new ApiError(401, 'Please sign in');
  }
  if (!response.ok) {
    const detail = data && data.details ? ` (${Object.values(data.details).join('; ')})` : '';
    throw new ApiError(response.status, `${(data && data.error) || 'Request failed'}${detail}`, data && data.details);
  }
  return data;
}

export const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body),
};
