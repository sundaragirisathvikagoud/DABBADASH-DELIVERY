import { h, clear, money, itemSummary } from './util.js';
import { api } from './api.js';
import { state } from './state.js';
import { toast } from './toast.js';
import { assignCourier, unassignOrder, dispatchCourier, assignBatch } from './actions.js';

// Remember each dropdown's choice across the 3-second refresh so it never resets under the user's hand.
const chosen = new Map();

function courierOption(c, order) {
  const eligible = c.eligible && c.free > 0;
  const label = `${c.name} · Sector ${c.zoneCode} · ${c.load}/${c.capacity}${eligible ? '' : ` (${c.status.replace('_', ' ')})`}`;
  return h('option', { value: c.id, disabled: !eligible, selected: eligible && (chosen.get(order.id) ?? order.recommendation?.courierId) === c.id }, label);
}

function awaitingRow(order) {
  const select = h('select', {
    'aria-label': `Courier for order ${order.id}`,
    onchange: (e) => chosen.set(order.id, Number(e.target.value)),
  }, ...state.couriers.map((c) => courierOption(c, order)));
  return h('div', { class: 'row' },
    h('div', { class: 'grow' },
      h('strong', {}, `#${order.id} `), h('span', { class: 'brand-chip', style: { '--brand': order.brandColor } }, order.brand),
      ' ', h('span', { class: 'zone-chip' }, `Sector ${order.zoneCode}`),
      h('div', { class: 'hint' }, `${itemSummary(order.items)} · ${order.customerName}`),
      order.recommendation && h('div', { class: 'reco-line' }, `Recommended: ${order.recommendation.name}. ${order.recommendation.reason}`)),
    select,
    h('button', {
      class: 'btn btn-small', type: 'button',
      onclick: () => assignCourier(order.id, Number(select.value) || order.recommendation?.courierId),
    }, 'Assign'));
}

function renderAwaiting() {
  const host = clear(document.getElementById('awaiting'));
  const waiting = state.orders.filter((o) => o.status === 'packed' && !o.courierId);
  if (!waiting.length) host.append(h('p', { class: 'hint' }, 'No packed orders are waiting. Mark an order as packed on the Kitchen Board.'));
  waiting.forEach((o) => host.append(awaitingRow(o)));
}

function renderBatches() {
  const host = clear(document.getElementById('batches'));
  document.getElementById('batchRadius').textContent = `(${state.radiusKm} km cluster radius)`;
  if (!state.batches.length) host.append(h('p', { class: 'hint' }, 'No orders are waiting to be batched.'));
  state.batches.forEach((b) => {
    const sug = b.suggestedCourier;
    host.append(h('div', { class: `batch${b.multi ? ' is-multi' : ''}` },
      h('div', { class: 'batch-head' },
        h('span', { class: 'zone-chip' }, `Sector ${b.zoneCode}`),
        h('span', {}, b.multi ? `${b.size} orders, one trip` : 'Single drop (no batching partner yet)'),
        b.multi && h('span', { class: 'saving' }, `Saves ${b.savedKm} km (${b.savedPct}%)`)),
      h('div', { class: 'batch-orders' }, b.orders.map((o) =>
        h('span', { class: `batch-order${o.ready ? '' : ' is-upcoming'}`, title: o.ready ? 'Packed, ready' : 'Still in the kitchen' },
          `#${o.id} ${o.brand}${o.ready ? '' : ' (cooking)'}`))),
      h('div', { class: 'hint' }, `Route ${b.batchedKm} km batched vs ${b.separateKm} km as separate trips · cluster radius ${b.radiusKm} km`),
      b.readyOrderIds.length
        ? (sug
          ? h('button', { class: 'btn btn-small', type: 'button', onclick: () => assignBatch(b, sug.courierId, sug.name) },
            `Assign ${b.readyOrderIds.length} packed order(s) to ${sug.name}`)
          : h('div', { class: 'hint' }, 'No single courier has enough free capacity. Assign these orders individually.'))
        : h('div', { class: 'hint' }, 'Waiting for the kitchen to pack these orders.')));
  });
}

function renderRiders() {
  const host = clear(document.getElementById('riders'));
  state.couriers.forEach((c) => {
    const assigned = state.orders.filter((o) => o.courierId === c.id && o.status === 'packed');
    host.append(h('div', { class: 'rider' },
      h('div', { class: 'rider-head' },
        h('strong', {}, c.name),
        h('span', { class: `pill pill-${c.status}` }, c.status.replace('_', ' ')),
        h('span', { class: 'hint' }, `${c.vehicle} · home Sector ${c.zoneCode}`)),
      h('div', { class: 'meter', role: 'img', 'aria-label': `${c.load} of ${c.capacity} order slots used` },
        h('span', { style: { width: `${Math.round((c.load / c.capacity) * 100)}%` } })),
      h('div', { class: 'hint' }, `${c.load}/${c.capacity} orders${c.trip ? ` · route ${c.trip.routeKm} km` : ''}`),
      c.trip && h('div', { class: 'rider-trip' },
        `Trip payout ${money(c.trip.payout.total)}`,
        c.trip.payout.surgeReason ? ` (incl. ${c.trip.payout.surgeReason} surge ${money(c.trip.payout.surgePay)})` : ''),
      assigned.length > 0 && h('div', { class: 'card-actions' },
        h('button', { class: 'btn btn-small btn-good', type: 'button', onclick: () => dispatchCourier(c) },
          `Dispatch ${assigned.length} order(s)`),
        ...assigned.map((o) => h('button', { class: 'btn btn-small btn-ghost', type: 'button', onclick: () => unassignOrder(o.id), title: 'Remove this order from the courier' }, `Unassign #${o.id}`)))));
  });
}

export function renderDispatch() {
  renderAwaiting();
  renderBatches();
  renderRiders();
}

export function initPayoutForm() {
  const form = document.getElementById('payoutForm');
  const out = document.getElementById('payoutResult');
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = new FormData(form);
    const body = { distanceKm: Number(data.get('distanceKm')), stops: Number(data.get('stops')) };
    if (data.get('peak') !== 'auto') body.peak = data.get('peak') === 'true';
    try {
      const { payout } = await api.post('/api/payout/estimate', body);
      const row = (k, v, cls) => [h('dt', { class: cls }, k), h('dd', { class: cls }, v)];
      clear(out).append(h('dl', {},
        ...row('Base fare', money(payout.base)),
        ...row(`Distance (${payout.distanceKm} km)`, money(payout.distancePay)),
        ...row('Multi-stop bonus', money(payout.extraStopPay)),
        ...row(payout.surgeReason ? `Surge x${payout.surgeMultiplier} (${payout.surgeReason})` : 'Surge', money(payout.surgePay)),
        ...row('Total earnings', money(payout.total), 'total')));
    } catch (err) {
      toast(err.message, { error: true });
    }
  });
}
