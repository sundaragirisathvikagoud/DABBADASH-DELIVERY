import { h } from './util.js';

/** Shows a transient notification. `action` is {label, onClick} for one-click follow-ups. */
export function toast(message, { error = false, action = null, ms = 6000 } = {}) {
  const host = document.getElementById('toasts');
  const el = h('div', { class: `toast${error ? ' is-error' : ''}`, role: error ? 'alert' : 'status' }, h('span', {}, message));
  if (action) {
    el.append(h('button', {
      class: 'btn btn-small', type: 'button',
      onclick: () => { el.remove(); action.onClick(); },
    }, action.label));
  }
  host.append(el);
  setTimeout(() => el.remove(), action ? ms + 4000 : ms);
}
