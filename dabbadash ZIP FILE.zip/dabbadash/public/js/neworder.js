import { h, clear, money } from './util.js';
import { api } from './api.js';
import { state, refreshAll } from './state.js';
import { toast } from './toast.js';

/** Wires up the "New order" dialog: brand-aware menu, client-side checks mirroring the server's rules. */
export function initNewOrder() {
  const dialog = document.getElementById('newOrderDialog');
  const form = document.getElementById('newOrderForm');
  const error = document.getElementById('newOrderError');
  const menuHost = document.getElementById('menuItems');
  const brandSelect = form.elements.brandId;
  const zoneSelect = form.elements.zoneId;

  function fillSelects() {
    clear(brandSelect).append(...state.meta.brands.map((b) => h('option', { value: b.id }, b.name)));
    clear(zoneSelect).append(...state.meta.zones.map((z) => h('option', { value: z.id }, z.name)));
  }

  function renderMenu() {
    const brandId = Number(brandSelect.value);
    clear(menuHost).append(...state.meta.menu.filter((m) => m.brandId === brandId).map((m) =>
      h('label', { class: 'menu-row' },
        h('span', {}, `${m.name} (${money(m.price)})`),
        h('input', { type: 'number', min: '0', max: '20', value: '0', 'data-menu-id': m.id, 'aria-label': `Quantity of ${m.name}` }))));
  }

  brandSelect.addEventListener('change', renderMenu);
  document.getElementById('btnNewOrder').addEventListener('click', () => {
    fillSelects();
    renderMenu();
    form.reset();
    brandSelect.value = state.meta.brands[0].id;
    renderMenu();
    error.textContent = '';
    dialog.showModal();
    form.elements.customerName.focus();
  });
  document.getElementById('newOrderCancel').addEventListener('click', () => dialog.close());

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const items = [...menuHost.querySelectorAll('input')]
      .map((i) => ({ menuItemId: Number(i.dataset.menuId), qty: Number(i.value) }))
      .filter((i) => i.qty > 0);
    if (!items.length) {
      error.textContent = 'Add at least one item.';
      return;
    }
    const body = {
      brandId: Number(brandSelect.value),
      zoneId: Number(zoneSelect.value),
      customerName: form.elements.customerName.value,
      phone: form.elements.phone.value,
      address: form.elements.address.value,
      items,
    };
    const submit = document.getElementById('newOrderSubmit');
    submit.disabled = true;
    try {
      const { order } = await api.post('/api/orders', body);
      dialog.close();
      toast(`Order #${order.id} placed for ${order.customerName}.`);
      await refreshAll();
    } catch (err) {
      error.textContent = err.message;
    } finally {
      submit.disabled = false;
    }
  });
}
