import { h, clear, money, mmss, clockTime } from './util.js';
import { api } from './api.js';
import { startRealtime } from './realtime.js';

/**
 * Customer-facing live tracker. No login: the unguessable token in the SMS link is the credential.
 * Between server updates the countdown and the scooter are animated locally once per second.
 */
const token = new URLSearchParams(window.location.search).get('t');
const root = document.getElementById('trackRoot');

let view = null;
let fetchedAt = 0;
let nodes = null;

function remainingSeconds() {
  if (!view) return 0;
  if (view.status === 'delivered') return 0;
  const elapsed = ((Date.now() - fetchedAt) / 1000) * (view.status === 'out_for_delivery' ? view.timeScale : 0);
  return Math.max(0, view.etaSeconds - elapsed);
}

function statusMessage() {
  switch (view.status) {
    case 'received': return 'Order received. The kitchen will start shortly.';
    case 'in_kitchen': return 'Your food is being freshly prepared.';
    case 'packed':
      return view.courierAssigned
        ? `Courier Assigned – ${view.courierName} is picking up your food!`
        : 'Packed and waiting for a courier.';
    case 'out_for_delivery':
      return remainingSeconds() <= 0 ? `${view.courierName} is arriving now.` : `${view.courierName} is on the way with your order.`;
    default: return `Delivered${view.courierName ? ` by ${view.courierName}` : ''}. Enjoy your meal!`;
  }
}

function build() {
  const stepEls = view.steps.map((s) => h('li', { class: 'step' }, s.label, h('time', {}, '')));
  nodes = {
    status: h('div', { class: 'track-status', role: 'status' }),
    etaValue: h('span', { class: 'eta-value' }),
    etaLabel: h('span', { class: 'hint' }),
    steps: stepEls,
    done: h('div', { class: 'lane-done' }),
    vehicle: h('div', { class: 'vehicle', 'aria-hidden': 'true' }, '🛵'),
  };
  clear(root).append(
    h('div', { class: 'logo logo-lg' }, h('span', { class: 'logo-mark', 'aria-hidden': 'true' }, '🍱'),
      h('span', { class: 'logo-text' }, 'Dabba', h('b', {}, 'Dash'))),
    h('h1', { class: 'track-title' }, `${view.brand} · Order #${view.orderId}`),
    nodes.status,
    h('div', { class: 'eta' }, nodes.etaValue, nodes.etaLabel),
    h('div', { class: 'lane', role: 'img', 'aria-label': 'Delivery progress' },
      h('div', { class: 'lane-road' }), nodes.done,
      h('span', { class: 'lane-kitchen', 'aria-hidden': 'true' }, '🍳'),
      h('span', { class: 'lane-home', 'aria-hidden': 'true' }, '🏠'),
      nodes.vehicle),
    h('ol', { class: 'stepper', 'aria-label': 'Order progress' }, ...stepEls),
    h('ul', { class: 'track-items' }, view.items.map((i) => h('li', {}, `${i.qty}× ${i.name}`))),
    h('div', { class: 'track-foot' }, h('span', {}, `Delivering to ${view.zoneName}`), h('span', {}, `Total ${money(view.total)}`)));
}

function paint() {
  if (!view || !nodes) return;
  const idx = view.steps.findIndex((s) => s.key === view.status);
  nodes.status.textContent = statusMessage();
  nodes.status.classList.toggle('is-done', view.status === 'delivered');

  nodes.steps.forEach((el, i) => {
    el.classList.toggle('is-done', i < idx || view.status === 'delivered');
    el.classList.toggle('is-current', i === idx && view.status !== 'delivered');
    if (i === idx && view.status !== 'delivered') el.setAttribute('aria-current', 'step');
    else el.removeAttribute('aria-current');
    el.querySelector('time').textContent = clockTime(view.steps[i].at);
  });

  const secs = remainingSeconds();
  if (view.status === 'delivered') {
    nodes.etaValue.textContent = 'Delivered';
    nodes.etaLabel.textContent = '';
  } else {
    nodes.etaValue.textContent = mmss(secs);
    nodes.etaLabel.textContent = view.status === 'out_for_delivery' ? 'until arrival' : 'estimated total time';
  }

  // Vehicle position along the lane: kitchen (6%) -> home (94%).
  let progress = 0;
  if (view.status === 'out_for_delivery') progress = 1 - secs / Math.max(1, view.etaTotalSeconds);
  if (view.status === 'delivered') progress = 1;
  const pct = 6 + Math.min(1, Math.max(0, progress)) * 88;
  nodes.vehicle.style.left = `${pct}%`;
  nodes.done.style.width = `${pct - 6}%`;
  nodes.vehicle.classList.toggle('is-moving', view.status === 'out_for_delivery' && secs > 0);
}

async function load() {
  try {
    view = await api.get(`/api/track/${encodeURIComponent(token)}`);
    fetchedAt = Date.now();
    if (!nodes) build();
    paint();
  } catch (err) {
    clear(root).append(h('p', { class: 'form-error', role: 'alert' },
      err.status === 404 ? 'This tracking link is not valid. Check the link in your SMS.' : err.message));
  }
}

if (!token) {
  clear(root).append(h('p', { class: 'form-error', role: 'alert' }, 'Missing tracking token. Open the link from your SMS.'));
} else {
  load().then(() => {
    if (!view) return;
    setInterval(paint, 1000);
    startRealtime({
      streamUrl: `/api/track/${encodeURIComponent(token)}/stream`,
      onChange: load,
      onStatus: () => {},
    });
  });
}
