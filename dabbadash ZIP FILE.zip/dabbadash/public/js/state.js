import { api } from './api.js';

/**
 * Single source of truth for dashboard data. Views subscribe and re-render only when
 * the data they care about actually changed (compared by JSON signature).
 */
export const state = {
  meta: null, // brands, zones, menu, kitchen (static reference data)
  orders: [],
  couriers: [],
  batches: [],
  metrics: null,
  sms: [],
  brandFilter: null,
  clockOffset: 0, // serverNow - clientNow, so timers match the server clock
};

const listeners = new Set();
const signatures = {};

export const subscribe = (fn) => listeners.add(fn);
export const serverNow = () => Date.now() + state.clockOffset;

function assign(key, value) {
  const sig = JSON.stringify(value);
  const changed = signatures[key] !== sig;
  signatures[key] = sig;
  state[key] = value;
  return changed;
}

let inFlight = null;

/** Fetches everything in parallel; coalesces overlapping calls. Returns the set of changed keys. */
export function refreshAll() {
  if (inFlight) return inFlight;
  inFlight = (async () => {
    const [orders, couriers, batches, metrics, sms] = await Promise.all([
      api.get('/api/orders'),
      api.get('/api/couriers'),
      api.get('/api/batches'),
      api.get('/api/metrics'),
      api.get('/api/sms'),
    ]);
    state.clockOffset = orders.serverNow - Date.now();
    const changed = new Set();
    if (assign('orders', orders.orders)) changed.add('orders');
    if (assign('couriers', couriers.couriers)) changed.add('couriers');
    if (assign('batches', batches.batches)) changed.add('batches');
    if (assign('metrics', { ...metrics, serverNow: 0 })) changed.add('metrics');
    if (assign('sms', sms.messages)) changed.add('sms');
    state.radiusKm = batches.radiusKm;
    listeners.forEach((fn) => fn(changed));
    return changed;
  })().finally(() => { inFlight = null; });
  return inFlight;
}

export async function loadMeta() {
  state.meta = await api.get('/api/state');
  return state.meta;
}
