'use strict';

const EARTH_RADIUS_KM = 6371;
const toRad = (deg) => (deg * Math.PI) / 180;

/** Great-circle distance between two {lat, lng} points in kilometres. */
function haversineKm(a, b) {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}

function centroid(points) {
  if (!points.length) return null;
  const sum = points.reduce((acc, p) => ({ lat: acc.lat + p.lat, lng: acc.lng + p.lng }), { lat: 0, lng: 0 });
  return { lat: sum.lat / points.length, lng: sum.lng / points.length };
}

/**
 * Nearest-neighbour route starting at `start` and visiting every stop once.
 * Returns the total distance and, per stop, the cumulative distance when reached.
 */
function routeKm(start, stops) {
  const remaining = [...stops];
  const legs = [];
  let current = start;
  let total = 0;
  while (remaining.length) {
    let best = 0;
    let bestDist = Infinity;
    remaining.forEach((stop, i) => {
      const d = haversineKm(current, stop);
      if (d < bestDist) {
        bestDist = d;
        best = i;
      }
    });
    total += bestDist;
    current = remaining.splice(best, 1)[0];
    legs.push({ stop: current, cumulativeKm: total });
  }
  return { totalKm: total, legs };
}

function lerp(a, b, t) {
  return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
}

const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
const round = (n, digits = 2) => Math.round(n * 10 ** digits) / 10 ** digits;

module.exports = { haversineKm, centroid, routeKm, lerp, clamp, round };
