'use strict';

const path = require('node:path');
const { createApp } = require('./app');

const PORT = Number(process.env.PORT) || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'dabbadash.db');

const app = createApp({ dbPath: DB_PATH });

app.server.listen(PORT, () => {
  console.log(`DabbaDash is running:  http://localhost:${PORT}`);
  console.log(`Database:              ${DB_PATH}`);
  if (app.usingDefaultPassword) {
    console.warn('WARNING: using the default demo login (manager / Dabba@123). Set MANAGER_PASSWORD before any real deployment.');
  }
});

function shutdown() {
  app.close().then(() => process.exit(0));
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
