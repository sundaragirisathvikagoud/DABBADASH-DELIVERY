'use strict';

/** An error that is safe to show to API clients. Anything else becomes a generic 500. */
class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.details = details;
  }
}

module.exports = { HttpError };
