'use strict';

const crypto = require('node:crypto');
const { SESSION_TTL_MS, LOGIN_MAX_ATTEMPTS, LOGIN_WINDOW_MS } = require('./config');

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };

/** Hashes a password with scrypt and a random per-password salt. Format: scrypt$N$r$p$salt$hash */
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return ['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('hex'), hash.toString('hex')].join('$');
}

/** Constant-time password verification. Returns false for any malformed stored hash. */
function verifyPassword(password, stored) {
  try {
    const [scheme, N, r, p, saltHex, hashHex] = String(stored).split('$');
    if (scheme !== 'scrypt') return false;
    const expected = Buffer.from(hashHex, 'hex');
    const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length, {
      N: Number(N), r: Number(r), p: Number(p),
    });
    return crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

// Used so a login for an unknown user costs the same as one for a known user.
const DUMMY_HASH = hashPassword('dabbadash-dummy-password');

const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');

/** Creates a session; only the SHA-256 of the token is stored, so a DB leak cannot hijack sessions. */
function createSession(db, userId, now = Date.now()) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)')
    .run(sha256(token), userId, now, now + SESSION_TTL_MS);
  return { token, maxAgeSeconds: Math.floor(SESSION_TTL_MS / 1000) };
}

function getSessionUser(db, token, now = Date.now()) {
  if (!token || typeof token !== 'string' || token.length > 200) return null;
  const row = db.prepare(`SELECT u.id, u.username, u.role, s.expires_at
    FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`).get(sha256(token));
  if (!row) return null;
  if (row.expires_at <= now) {
    destroySession(db, token);
    return null;
  }
  return { id: row.id, username: row.username, role: row.role };
}

function destroySession(db, token) {
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
}

function purgeExpiredSessions(db, now = Date.now()) {
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(now);
}

/** Verifies credentials; returns the user row or null. */
function authenticate(db, username, password) {
  const user = db.prepare('SELECT id, username, role, password_hash FROM users WHERE username = ?').get(username);
  const ok = verifyPassword(password, user ? user.password_hash : DUMMY_HASH);
  return user && ok ? { id: user.id, username: user.username, role: user.role } : null;
}

function ensureUser(db, username, password, role = 'manager', now = Date.now()) {
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return false;
  db.prepare('INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)')
    .run(username, hashPassword(password), role, now);
  return true;
}

/** Sliding-window limiter for failed logins, keyed by ip+username. In-memory by design (single process). */
class LoginLimiter {
  constructor(max = LOGIN_MAX_ATTEMPTS, windowMs = LOGIN_WINDOW_MS) {
    this.max = max;
    this.windowMs = windowMs;
    this.failures = new Map();
  }

  #recent(key, now) {
    const list = (this.failures.get(key) || []).filter((t) => now - t < this.windowMs);
    if (list.length) this.failures.set(key, list);
    else this.failures.delete(key);
    return list;
  }

  /** Seconds the caller must wait, or 0 when allowed. */
  retryAfter(key, now = Date.now()) {
    const list = this.#recent(key, now);
    if (list.length < this.max) return 0;
    return Math.ceil((list[0] + this.windowMs - now) / 1000);
  }

  recordFailure(key, now = Date.now()) {
    const list = this.#recent(key, now);
    list.push(now);
    this.failures.set(key, list);
  }

  reset(key) {
    this.failures.delete(key);
  }
}

module.exports = {
  hashPassword, verifyPassword, createSession, getSessionUser, destroySession,
  purgeExpiredSessions, authenticate, ensureUser, LoginLimiter,
};
