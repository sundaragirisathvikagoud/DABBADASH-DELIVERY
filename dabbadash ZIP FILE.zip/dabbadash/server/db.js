'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS brands (
  id      INTEGER PRIMARY KEY,
  name    TEXT NOT NULL UNIQUE,
  color   TEXT NOT NULL,
  tagline TEXT
);

CREATE TABLE IF NOT EXISTS menu_items (
  id       INTEGER PRIMARY KEY,
  brand_id INTEGER NOT NULL REFERENCES brands(id),
  name     TEXT NOT NULL,
  price    REAL NOT NULL CHECK (price > 0),
  UNIQUE (brand_id, name)
);

CREATE TABLE IF NOT EXISTS zones (
  id   INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  lat  REAL NOT NULL,
  lng  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS couriers (
  id       INTEGER PRIMARY KEY,
  name     TEXT NOT NULL,
  vehicle  TEXT NOT NULL CHECK (vehicle IN ('bicycle', 'scooter', 'bike')),
  capacity INTEGER NOT NULL CHECK (capacity BETWEEN 1 AND 8),
  zone_id  INTEGER NOT NULL REFERENCES zones(id),
  lat      REAL NOT NULL,
  lng      REAL NOT NULL,
  active   INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  brand_id       INTEGER NOT NULL REFERENCES brands(id),
  customer_name  TEXT NOT NULL,
  phone          TEXT NOT NULL,
  address        TEXT NOT NULL,
  zone_id        INTEGER NOT NULL REFERENCES zones(id),
  lat            REAL NOT NULL,
  lng            REAL NOT NULL,
  status         TEXT NOT NULL CHECK (status IN ('received','in_kitchen','packed','out_for_delivery','delivered')),
  courier_id     INTEGER REFERENCES couriers(id),
  total          REAL NOT NULL,
  tracking_token TEXT NOT NULL UNIQUE,
  created_at     INTEGER NOT NULL,
  kitchen_at     INTEGER,
  packed_at      INTEGER,
  out_at         INTEGER,
  delivered_at   INTEGER,
  eta_total_s    INTEGER
);
CREATE INDEX IF NOT EXISTS idx_orders_status  ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_courier ON orders(courier_id);

CREATE TABLE IF NOT EXISTS order_items (
  id           INTEGER PRIMARY KEY,
  order_id     INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  menu_item_id INTEGER REFERENCES menu_items(id),
  name         TEXT NOT NULL,
  qty          INTEGER NOT NULL CHECK (qty BETWEEN 1 AND 20),
  price        REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS order_events (
  id       INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status   TEXT NOT NULL,
  note     TEXT,
  at       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sms_log (
  id         INTEGER PRIMARY KEY,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  phone      TEXT NOT NULL,
  body       TEXT NOT NULL,
  link       TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'manager',
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
`;

/** Opens (and creates if needed) the SQLite database. Use ':memory:' for tests. */
function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 3000;');
  db.exec(SCHEMA);
  return db;
}

/** Runs `fn` inside an immediate transaction; rolls back if it throws. Not re-entrant. */
function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { openDb, tx };
