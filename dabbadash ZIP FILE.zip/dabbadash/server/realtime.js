'use strict';

/**
 * Server-Sent Events hub. Managers subscribe to everything; a customer tracking page
 * subscribes to exactly one order, so it can never observe another customer's updates.
 * Clients also poll every 3 seconds, so SSE is an optimisation, not a single point of failure.
 */
class Hub {
  constructor(heartbeatMs = 25000) {
    this.clients = new Set();
    this.timer = setInterval(() => this.#each((c) => c.res.write(': keep-alive\n\n')), heartbeatMs);
    this.timer.unref();
  }

  /** @param orderId number|null - null subscribes to all events (manager). */
  subscribe(req, res, orderId = null) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write('retry: 3000\n\n');
    const client = { res, orderId };
    this.clients.add(client);
    req.on('close', () => this.clients.delete(client));
    res.write(`event: hello\ndata: ${JSON.stringify({ connected: true })}\n\n`);
  }

  /** @param event {type: string, orderIds: number[]} */
  broadcast(event) {
    const payload = `event: update\ndata: ${JSON.stringify({ type: event.type, at: Date.now() })}\n\n`;
    this.#each((c) => {
      if (c.orderId === null || (event.orderIds || []).includes(c.orderId)) c.res.write(payload);
    });
  }

  #each(fn) {
    for (const client of this.clients) {
      try {
        fn(client);
      } catch {
        this.clients.delete(client);
      }
    }
  }

  close() {
    clearInterval(this.timer);
    for (const client of this.clients) client.res.end();
    this.clients.clear();
  }
}

module.exports = { Hub };
