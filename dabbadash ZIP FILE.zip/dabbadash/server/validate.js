'use strict';

const { HttpError } = require('./errors');

// Control characters and angle brackets are never legitimate in names/addresses.
const FORBIDDEN_TEXT = /[\u0000-\u001f\u007f<>]/;

/**
 * Collects field errors so the client sees every problem at once.
 * Usage: const v = new Validator(); const x = v.int(input.x, 'x', {min:1}); v.assert();
 */
class Validator {
  constructor() {
    this.errors = {};
  }

  fail(field, message) {
    if (!this.errors[field]) this.errors[field] = message;
    return undefined;
  }

  text(value, field, { min = 1, max = 100 } = {}) {
    if (typeof value !== 'string') return this.fail(field, 'must be text');
    const clean = value.trim().replace(/\s+/g, ' ');
    if (clean.length < min || clean.length > max) {
      return this.fail(field, `must be ${min}-${max} characters`);
    }
    if (FORBIDDEN_TEXT.test(clean)) return this.fail(field, 'contains invalid characters');
    return clean;
  }

  int(value, field, { min = 0, max = Number.MAX_SAFE_INTEGER } = {}) {
    if (!Number.isInteger(value) || value < min || value > max) {
      return this.fail(field, `must be a whole number between ${min} and ${max}`);
    }
    return value;
  }

  number(value, field, { min = -Infinity, max = Infinity } = {}) {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) {
      return this.fail(field, `must be a number between ${min} and ${max}`);
    }
    return value;
  }

  phone(value, field) {
    if (typeof value !== 'string') return this.fail(field, 'must be a phone number');
    const digits = value.replace(/[\s-]/g, '');
    if (!/^\+?[0-9]{10,13}$/.test(digits)) return this.fail(field, 'must be a valid phone number (10-13 digits)');
    return digits;
  }

  bool(value, field) {
    if (typeof value !== 'boolean') return this.fail(field, 'must be true or false');
    return value;
  }

  get valid() {
    return Object.keys(this.errors).length === 0;
  }

  assert() {
    if (!this.valid) throw new HttpError(400, 'Validation failed', this.errors);
  }
}

/** Parses an id taken from a URL path; throws 400 on anything but a positive integer. */
function idParam(raw, name = 'id') {
  if (!/^[1-9][0-9]{0,9}$/.test(String(raw))) throw new HttpError(400, `Invalid ${name}`);
  return Number(raw);
}

module.exports = { Validator, idParam };
