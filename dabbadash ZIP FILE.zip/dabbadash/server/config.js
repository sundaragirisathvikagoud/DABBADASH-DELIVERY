'use strict';

/**
 * Central, immutable configuration for business rules.
 * Nothing in here is secret; secrets come from environment variables only.
 */
const positive = (value, fallback) => {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

module.exports = Object.freeze({
  /** The single commissary kitchen that all virtual brands share. */
  KITCHEN: Object.freeze({ name: 'DabbaDash Commissary, Madhapur', lat: 17.45, lng: 78.38 }),

  /** Ordered lifecycle of an order. Index order == allowed transition order. */
  STATUSES: Object.freeze(['received', 'in_kitchen', 'packed', 'out_for_delivery', 'delivered']),
  STATUS_LABELS: Object.freeze({
    received: 'Received',
    in_kitchen: 'In Kitchen',
    packed: 'Packed',
    out_for_delivery: 'Out for Delivery',
    delivered: 'Delivered',
  }),

  /** Orders sitting in the kitchen longer than this are flagged as bottlenecks. */
  BOTTLENECK_MINUTES: 20,

  /** Hyperlocal Sector Clustering Heuristic: orders within this radius share a batch. */
  CLUSTER_RADIUS_KM: 2.5,
  MAX_BATCH_SIZE: 4,

  /** Transit model used for ETAs (no live GPS hardware is assumed). */
  AVG_SPEED_KMH: 18,
  STOP_MINUTES: 2,
  MIN_TRANSIT_SECONDS: 300,
  /** Demo helper: >1 makes simulated deliveries complete faster (env TIME_SCALE). */
  TIME_SCALE: positive(process.env.TIME_SCALE, 1),

  /** Rider payout model (INR). */
  PAYOUT: Object.freeze({
    base: 25,
    perKm: 8,
    extraStop: 10,
    peakMultiplier: 1.3,
    demandMultiplier: 1.2,
    demandThreshold: 8,
  }),

  SESSION_TTL_MS: 8 * 60 * 60 * 1000,
  MAX_BODY_BYTES: 100 * 1024,
  LOGIN_MAX_ATTEMPTS: 5,
  LOGIN_WINDOW_MS: 60 * 1000,
  UTC_OFFSET_MS: 5.5 * 60 * 60 * 1000, // IST, used for peak-hour detection
});
