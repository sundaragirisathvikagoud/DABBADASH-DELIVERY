'use strict';

const cfg = require('../config');
const { round } = require('../geo');

/** Live operational KPIs for the top bar of the manager dashboard. */
function computeMetrics(db, now = Date.now()) {
  const counts = Object.fromEntries(cfg.STATUSES.map((s) => [s, 0]));
  db.prepare('SELECT status, COUNT(*) AS n FROM orders GROUP BY status').all().forEach((r) => {
    counts[r.status] = r.n;
  });

  // Average kitchen prep time over the 50 most recently packed orders.
  const prep = db.prepare(`SELECT AVG((packed_at - kitchen_at) / 60000.0) AS avg_minutes FROM
    (SELECT packed_at, kitchen_at FROM orders WHERE packed_at IS NOT NULL AND kitchen_at IS NOT NULL
     ORDER BY packed_at DESC LIMIT 50)`).get();

  const pendingDispatch = db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status = 'packed' AND courier_id IS NULL").get().n;
  const bottlenecks = db.prepare(
    "SELECT COUNT(*) AS n FROM orders WHERE status = 'in_kitchen' AND ? - kitchen_at > ?"
  ).get(now, cfg.BOTTLENECK_MINUTES * 60 * 1000).n;
  const riders = db.prepare(`SELECT
      SUM(CASE WHEN c.active = 1 AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.courier_id = c.id AND o.status = 'out_for_delivery') THEN 1 ELSE 0 END) AS at_kitchen,
      SUM(CASE WHEN EXISTS (SELECT 1 FROM orders o WHERE o.courier_id = c.id AND o.status = 'out_for_delivery') THEN 1 ELSE 0 END) AS on_delivery
    FROM couriers c`).get();

  const byBrand = db.prepare(`SELECT b.id, b.name, b.color, COUNT(o.id) AS active
    FROM brands b LEFT JOIN orders o ON o.brand_id = b.id AND o.status != 'delivered'
    GROUP BY b.id ORDER BY b.id`).all();

  return {
    activeOrders: cfg.STATUSES.filter((s) => s !== 'delivered').reduce((n, s) => n + counts[s], 0),
    inKitchen: counts.received + counts.in_kitchen,
    avgPrepMinutes: prep.avg_minutes == null ? null : round(prep.avg_minutes, 1),
    pendingDispatch,
    dispatched: counts.out_for_delivery,
    delivered: counts.delivered,
    bottlenecks,
    ridersAtKitchen: riders.at_kitchen || 0,
    ridersOnDelivery: riders.on_delivery || 0,
    counts,
    byBrand: byBrand.map((b) => ({ id: b.id, name: b.name, color: b.color, active: b.active })),
    bottleneckMinutes: cfg.BOTTLENECK_MINUTES,
    serverNow: now,
  };
}

module.exports = { computeMetrics };
