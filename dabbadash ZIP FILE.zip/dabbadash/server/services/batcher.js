'use strict';

const cfg = require('../config');
const { haversineKm, centroid, routeKm, round } = require('../geo');
const { hydrate } = require('./orders');

/**
 * Hyperlocal Sector Clustering Heuristic (pure function).
 *
 * Greedy, seed-based clustering: take the oldest unbatched order as a seed, pull in the
 * nearest orders within `radiusKm` of the seed (up to `maxSize` per batch), repeat.
 * Oldest-first seeding means the longest-waiting order always anchors a batch, so batching
 * never starves an old order. Complexity is O(n^2), fine for a single kitchen's live queue.
 *
 * @param points [{id, lat, lng, createdAt}]
 * @returns array of arrays of points
 */
function clusterOrders(points, { radiusKm = cfg.CLUSTER_RADIUS_KM, maxSize = cfg.MAX_BATCH_SIZE } = {}) {
  const remaining = [...points].sort((a, b) => a.createdAt - b.createdAt || a.id - b.id);
  const clusters = [];
  while (remaining.length) {
    const seed = remaining.shift();
    const near = remaining
      .map((p) => ({ p, d: haversineKm(seed, p) }))
      .filter((x) => x.d <= radiusKm)
      .sort((a, b) => a.d - b.d || a.p.id - b.p.id)
      .slice(0, Math.max(0, maxSize - 1))
      .map((x) => x.p);
    near.forEach((p) => remaining.splice(remaining.indexOf(p), 1));
    clusters.push([seed, ...near]);
  }
  return clusters;
}

/**
 * Builds delivery batches from orders not yet given to a courier. Orders that are still in the
 * kitchen are included as "upcoming" so the manager can plan, but only packed orders are assignable.
 *
 * `rankCouriers` is injected (from couriers.js) to avoid a circular import.
 */
function buildBatches(db, now, courierContext, rankCouriers) {
  const rows = db.prepare(`SELECT o.*, b.name AS brand_name, b.color AS brand_color, z.code AS zone_code,
      z.name AS zone_name, NULL AS courier_name
    FROM orders o JOIN brands b ON b.id = o.brand_id JOIN zones z ON z.id = o.zone_id
    WHERE o.status IN ('in_kitchen', 'packed') AND o.courier_id IS NULL`).all();
  const orders = hydrate(db, rows, now);
  const byId = new Map(orders.map((o) => [o.id, o]));

  const clusters = clusterOrders(orders.map((o) => ({ id: o.id, lat: o.lat, lng: o.lng, createdAt: o.createdAt })));

  const batches = clusters.map((members) => {
    const full = members.map((m) => byId.get(m.id));
    const ready = full.filter((o) => o.status === 'packed');
    const center = centroid(full);
    const separateKm = full.reduce((sum, o) => sum + haversineKm(cfg.KITCHEN, o), 0);
    const batchedKm = routeKm(cfg.KITCHEN, full).totalKm;
    const savedKm = Math.max(0, separateKm - batchedKm);

    // Suggest a courier who can take every ready order in one trip.
    let suggestion = null;
    if (ready.length) {
      const probe = { lat: center.lat, lng: center.lng };
      const fits = rankCouriers(courierContext, probe).filter((c) => c.free >= ready.length);
      if (fits.length) suggestion = { courierId: fits[0].courierId, name: fits[0].name, zoneCode: fits[0].zoneCode };
    }

    const zoneCounts = new Map();
    full.forEach((o) => zoneCounts.set(o.zoneCode, (zoneCounts.get(o.zoneCode) || 0) + 1));
    const zoneCode = [...zoneCounts].sort((a, b) => b[1] - a[1])[0][0];

    return {
      id: `B-${zoneCode}-${members[0].id}`,
      zoneCode,
      size: full.length,
      multi: full.length > 1,
      readyOrderIds: ready.map((o) => o.id),
      centroid: center,
      radiusKm: round(Math.max(...full.map((o) => haversineKm(center, o))), 2),
      separateKm: round(separateKm, 1),
      batchedKm: round(batchedKm, 1),
      savedKm: round(savedKm, 1),
      savedPct: separateKm > 0 ? Math.round((savedKm / separateKm) * 100) : 0,
      suggestedCourier: suggestion,
      orders: full.map((o) => ({
        id: o.id, brand: o.brand, brandColor: o.brandColor, status: o.status,
        zoneCode: o.zoneCode, itemCount: o.itemCount, ready: o.status === 'packed',
      })),
    };
  });

  // Multi-order batches first (that is where the savings are), then by size.
  return batches.sort((a, b) => b.size - a.size || a.id.localeCompare(b.id));
}

module.exports = { clusterOrders, buildBatches };
