'use strict';

const { PAYOUT, UTC_OFFSET_MS } = require('../config');
const { round } = require('../geo');

/** Peak hours (IST): lunch 12:00-15:00 and dinner 19:00-22:00. */
function isPeakHour(now) {
  const hour = new Date(now + UTC_OFFSET_MS).getUTCHours();
  return (hour >= 12 && hour < 15) || (hour >= 19 && hour < 22);
}

/**
 * Rider payout = (base + distance pay + extra-stop bonus) x surge multiplier.
 * Surge applies at peak hours (1.3x) or when the kitchen backlog is large (1.2x); the higher wins.
 */
function calculate({ distanceKm, stops, now = Date.now(), kitchenBacklog = 0, forcePeak = null }) {
  const base = PAYOUT.base;
  const distancePay = round(distanceKm * PAYOUT.perKm);
  const extraStopPay = Math.max(0, stops - 1) * PAYOUT.extraStop;
  const subtotal = base + distancePay + extraStopPay;

  const peak = forcePeak === null ? isPeakHour(now) : forcePeak;
  const highDemand = kitchenBacklog >= PAYOUT.demandThreshold;
  let multiplier = 1;
  let surgeReason = null;
  if (peak) {
    multiplier = PAYOUT.peakMultiplier;
    surgeReason = 'Peak hour';
  }
  if (highDemand && PAYOUT.demandMultiplier > multiplier) {
    multiplier = PAYOUT.demandMultiplier;
    surgeReason = 'High kitchen demand';
  }
  const surgePay = round(subtotal * (multiplier - 1));

  return {
    distanceKm: round(distanceKm, 1),
    stops,
    base,
    distancePay,
    extraStopPay,
    surgeMultiplier: multiplier,
    surgeReason,
    surgePay,
    total: round(subtotal + surgePay),
  };
}

module.exports = { calculate, isPeakHour };
