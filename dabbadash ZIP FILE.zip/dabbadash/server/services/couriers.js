'use strict';

const cfg = require('../config');
const { tx } = require('../db');
const { HttpError } = require('../errors');
const { haversineKm, routeKm, lerp, clamp, round } = require('../geo');
const { transitSeconds } = require('../eta');
const orders = require('./orders');
const sms = require('./sms');
const payout = require('./payout');

/** Active workload per courier: packed (assigned, awaiting dispatch) + out for delivery. */
function loadCourierContext(db, now = Date.now()) {
  const couriers = db.prepare(`SELECT c.*, z.code AS zone_code, z.name AS zone_name
    FROM couriers c JOIN zones z ON z.id = c.zone_id ORDER BY c.id`).all();
  const active = db.prepare(`SELECT id, courier_id, status, lat, lng, out_at, eta_total_s
    FROM orders WHERE courier_id IS NOT NULL AND status IN ('packed', 'out_for_delivery')
    ORDER BY out_at, id`).all();
  const backlog = db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status IN ('received', 'in_kitchen')").get().n;

  const byCourier = new Map();
  active.forEach((o) => {
    if (!byCourier.has(o.courier_id)) byCourier.set(o.courier_id, []);
    byCourier.get(o.courier_id).push(o);
  });

  return couriers.map((c) => {
    const mine = byCourier.get(c.id) || [];
    const out = mine.filter((o) => o.status === 'out_for_delivery');
    const load = mine.length;
    let status = 'available';
    if (!c.active) status = 'offline';
    else if (out.length) status = 'on_delivery';
    else if (load >= c.capacity) status = 'full';

    // Live position: interpolated along the kitchen -> first drop leg while out for delivery.
    let position = { lat: c.lat, lng: c.lng };
    if (out.length) {
      const first = out[0];
      const t = clamp(((now - first.out_at) / 1000 * cfg.TIME_SCALE) / first.eta_total_s, 0, 1);
      position = lerp(cfg.KITCHEN, first, t);
    } else if (load > 0) {
      position = { lat: cfg.KITCHEN.lat, lng: cfg.KITCHEN.lng }; // waiting at the kitchen for pickup
    }

    let trip = null;
    if (mine.length) {
      const route = routeKm(cfg.KITCHEN, mine);
      trip = {
        orderIds: mine.map((o) => o.id),
        routeKm: round(route.totalKm, 1),
        payout: payout.calculate({ distanceKm: route.totalKm, stops: mine.length, now, kitchenBacklog: backlog }),
      };
    }

    return {
      id: c.id,
      name: c.name,
      vehicle: c.vehicle,
      capacity: c.capacity,
      zoneId: c.zone_id,
      zoneCode: c.zone_code,
      zoneName: c.zone_name,
      active: Boolean(c.active),
      load,
      free: Math.max(0, c.capacity - load),
      status,
      eligible: status === 'available',
      base: { lat: c.lat, lng: c.lng },
      position,
      drops: mine.map((o) => ({ id: o.id, lat: o.lat, lng: o.lng, status: o.status })),
      trip,
    };
  });
}

function listCouriers(db, now = Date.now()) {
  return loadCourierContext(db, now);
}

/**
 * Ranks couriers able to take a drop at `point`, best first.
 * score (lower = better) = distance from the courier's home base
 *                          + 0.4 km per order already carried
 *                          - 1.5 km bonus if they already carry an order within the cluster radius.
 */
function rankCouriers(context, point) {
  return context
    .filter((c) => c.eligible && c.free > 0)
    .map((c) => {
      const distanceKm = haversineKm(c.base, point);
      const sharesRun = c.drops.some((d) => haversineKm(d, point) <= cfg.CLUSTER_RADIUS_KM);
      const score = distanceKm + c.load * 0.4 - (sharesRun ? 1.5 : 0);
      const reason = sharesRun
        ? `Already carrying a nearby order (${c.load}/${c.capacity} used)`
        : `${round(distanceKm, 1)} km from home base (${c.load}/${c.capacity} used)`;
      return { courierId: c.id, name: c.name, zoneCode: c.zoneCode, free: c.free, distanceKm: round(distanceKm, 1), score, reason };
    })
    .sort((a, b) => a.score - b.score || a.courierId - b.courierId);
}

function recommendFor(db, orderId, now = Date.now()) {
  const row = orders.getRow(db, orderId);
  if (!row) throw new HttpError(404, 'Order not found');
  return rankCouriers(loadCourierContext(db, now), row);
}

/** Adds `recommendation` (best courier) to packed, unassigned orders. */
function attachRecommendations(db, list, now = Date.now()) {
  const needs = list.filter((o) => o.status === 'packed' && !o.courierId);
  if (!needs.length) return list;
  const context = loadCourierContext(db, now);
  needs.forEach((o) => {
    const best = rankCouriers(context, o)[0];
    o.recommendation = best ? { courierId: best.courierId, name: best.name, zoneCode: best.zoneCode, reason: best.reason } : null;
  });
  return list;
}

function requireCourier(db, courierId) {
  const courier = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId);
  if (!courier) throw new HttpError(404, 'Courier not found');
  if (!courier.active) throw new HttpError(409, `${courier.name} is offline`);
  return courier;
}

function assertCourierAtKitchen(db, courier) {
  const away = db.prepare("SELECT COUNT(*) AS n FROM orders WHERE courier_id = ? AND status = 'out_for_delivery'").get(courier.id).n;
  if (away) throw new HttpError(409, `${courier.name} is out on a delivery and cannot take new orders yet`);
}

function currentLoad(db, courierId, excludeIds = []) {
  const rows = db.prepare("SELECT id FROM orders WHERE courier_id = ? AND status IN ('packed', 'out_for_delivery')").all(courierId);
  return rows.filter((r) => !excludeIds.includes(r.id)).length;
}

/** Assigns one packed order to a courier, enforcing vehicle capacity. */
function assignOrder(db, orderId, courierId, now, baseUrl) {
  return tx(db, () => {
    const row = orders.getRow(db, orderId);
    if (!row) throw new HttpError(404, 'Order not found');
    if (row.status !== 'packed') throw new HttpError(409, 'Only packed orders can be assigned to a courier');
    const courier = requireCourier(db, courierId);
    assertCourierAtKitchen(db, courier);
    if (currentLoad(db, courierId, [orderId]) + 1 > courier.capacity) {
      throw new HttpError(409, `${courier.name}'s ${courier.vehicle} is at capacity (${courier.capacity} orders)`);
    }
    db.prepare('UPDATE orders SET courier_id = ? WHERE id = ?').run(courierId, orderId);
    orders.logEvent(db, orderId, 'packed', now, `Courier assigned: ${courier.name}`);
    sms.queue(db, { ...row, courier_name: courier.name }, 'assigned', now, baseUrl);
    return orders.getOrder(db, orderId, now);
  });
}

function unassignOrder(db, orderId, now) {
  return tx(db, () => {
    const row = orders.getRow(db, orderId);
    if (!row) throw new HttpError(404, 'Order not found');
    if (row.status !== 'packed' || !row.courier_id) throw new HttpError(409, 'Order has no pending courier assignment');
    db.prepare('UPDATE orders SET courier_id = NULL WHERE id = ?').run(orderId);
    orders.logEvent(db, orderId, 'packed', now, 'Courier unassigned');
    return orders.getOrder(db, orderId, now);
  });
}

/** Assigns several packed orders (a hyperlocal batch) to one courier atomically. */
function assignBatch(db, orderIds, courierId, now, baseUrl) {
  if (!Array.isArray(orderIds) || orderIds.length < 1 || orderIds.length > cfg.MAX_BATCH_SIZE
      || !orderIds.every((id) => Number.isInteger(id) && id > 0)) {
    throw new HttpError(400, 'Validation failed', { orderIds: `must list 1-${cfg.MAX_BATCH_SIZE} order ids` });
  }
  const unique = [...new Set(orderIds)];
  return tx(db, () => {
    const courier = requireCourier(db, courierId);
    assertCourierAtKitchen(db, courier);
    const rows = unique.map((id) => {
      const row = orders.getRow(db, id);
      if (!row) throw new HttpError(404, `Order #${id} not found`);
      if (row.status !== 'packed') throw new HttpError(409, `Order #${id} is not packed yet`);
      if (row.courier_id && row.courier_id !== courierId) throw new HttpError(409, `Order #${id} already has a courier`);
      return row;
    });
    if (currentLoad(db, courierId, unique) + rows.length > courier.capacity) {
      throw new HttpError(409, `${courier.name}'s ${courier.vehicle} cannot carry ${rows.length} more orders (capacity ${courier.capacity})`);
    }
    rows.forEach((row) => {
      db.prepare('UPDATE orders SET courier_id = ? WHERE id = ?').run(courierId, row.id);
      orders.logEvent(db, row.id, 'packed', now, `Courier assigned: ${courier.name} (batch)`);
      sms.queue(db, { ...row, courier_name: courier.name }, 'assigned', now, baseUrl);
    });
    return unique;
  });
}

/** Sends a courier out with every packed order assigned to them, on one optimised multi-stop route. */
function dispatchCourier(db, courierId, now, baseUrl) {
  return tx(db, () => {
    const courier = requireCourier(db, courierId);
    const rows = db.prepare(`SELECT id FROM orders WHERE courier_id = ? AND status = 'packed' ORDER BY id`).all(courierId)
      .map((r) => orders.getRow(db, r.id));
    if (!rows.length) throw new HttpError(409, `${courier.name} has no packed orders to dispatch`);

    const route = routeKm(cfg.KITCHEN, rows);
    route.legs.forEach((leg, index) => {
      const etaTotalS = transitSeconds(leg.cumulativeKm, index);
      orders.applyTransition(db, leg.stop, 'out_for_delivery', now, { etaTotalS, note: `Stop ${index + 1} of ${rows.length}` });
      sms.queue(db, { ...leg.stop, status: 'out_for_delivery' }, 'out_for_delivery', now, baseUrl, {
        etaMinutes: Math.max(1, Math.ceil(etaTotalS / 60)),
      });
    });
    return route.legs.map((leg) => leg.stop.id);
  });
}

function payoutEstimate(db, courierId, now = Date.now()) {
  const courier = loadCourierContext(db, now).find((c) => c.id === courierId);
  if (!courier) throw new HttpError(404, 'Courier not found');
  return { courierId, name: courier.name, trip: courier.trip };
}

module.exports = {
  loadCourierContext, listCouriers, rankCouriers, recommendFor, attachRecommendations,
  assignOrder, unassignOrder, assignBatch, dispatchCourier, payoutEstimate,
};
