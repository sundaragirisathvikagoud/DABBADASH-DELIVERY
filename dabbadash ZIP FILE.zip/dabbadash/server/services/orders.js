'use strict';

const crypto = require('node:crypto');
const cfg = require('../config');
const { tx } = require('../db');
const { HttpError } = require('../errors');
const { haversineKm } = require('../geo');
const { transitSeconds } = require('../eta');
const { Validator } = require('../validate');
const sms = require('./sms');

const { STATUSES, STATUS_LABELS } = cfg;

// Column written when an order enters a status. Fixed map => no dynamic SQL from user input.
const TIME_COLUMN = {
  in_kitchen: 'kitchen_at',
  packed: 'packed_at',
  out_for_delivery: 'out_at',
  delivered: 'delivered_at',
};

const SELECT = `SELECT o.*, b.name AS brand_name, b.color AS brand_color,
    z.code AS zone_code, z.name AS zone_name, c.name AS courier_name
  FROM orders o
  JOIN brands b ON b.id = o.brand_id
  JOIN zones z ON z.id = o.zone_id
  LEFT JOIN couriers c ON c.id = o.courier_id`;

function getRow(db, id) {
  return db.prepare(`${SELECT} WHERE o.id = ?`).get(id);
}

function getRowByToken(db, token) {
  if (typeof token !== 'string' || token.length < 6 || token.length > 64) return undefined;
  return db.prepare(`${SELECT} WHERE o.tracking_token = ?`).get(token);
}

/** Timestamp at which the order entered its current status. */
function statusSince(row) {
  switch (row.status) {
    case 'in_kitchen': return row.kitchen_at;
    case 'packed': return row.packed_at;
    case 'out_for_delivery': return row.out_at;
    case 'delivered': return row.delivered_at;
    default: return row.created_at;
  }
}

function isBottleneck(row, now) {
  return row.status === 'in_kitchen' && now - row.kitchen_at > cfg.BOTTLENECK_MINUTES * 60 * 1000;
}

/** Seconds until delivery: live countdown while out for delivery, an estimate before that. */
function etaSeconds(row, now) {
  if (row.status === 'delivered') return 0;
  if (row.status === 'out_for_delivery') {
    const elapsed = ((now - row.out_at) / 1000) * cfg.TIME_SCALE;
    return Math.max(0, Math.ceil(row.eta_total_s - elapsed));
  }
  const transit = transitSeconds(haversineKm(cfg.KITCHEN, row), 0);
  let prep = 180;
  if (row.status === 'received') prep = 15 * 60;
  if (row.status === 'in_kitchen') prep = Math.max(120, 12 * 60 - (now - row.kitchen_at) / 1000);
  return Math.round(prep + transit);
}

function toApi(row, items, now) {
  return {
    id: row.id,
    brandId: row.brand_id,
    brand: row.brand_name,
    brandColor: row.brand_color,
    customerName: row.customer_name,
    phone: sms.maskPhone(row.phone),
    address: row.address,
    zoneId: row.zone_id,
    zoneCode: row.zone_code,
    zoneName: row.zone_name,
    lat: row.lat,
    lng: row.lng,
    status: row.status,
    statusLabel: STATUS_LABELS[row.status],
    courierId: row.courier_id,
    courierName: row.courier_name,
    items: items.map((i) => ({ name: i.name, qty: i.qty, price: i.price })),
    itemCount: items.reduce((n, i) => n + i.qty, 0),
    total: row.total,
    trackingToken: row.tracking_token,
    createdAt: row.created_at,
    kitchenAt: row.kitchen_at,
    packedAt: row.packed_at,
    outAt: row.out_at,
    deliveredAt: row.delivered_at,
    statusSince: statusSince(row),
    bottleneck: isBottleneck(row, now),
    etaSeconds: etaSeconds(row, now),
    etaTotalSeconds: row.eta_total_s,
  };
}

function hydrate(db, rows, now) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const items = db.prepare(
    `SELECT order_id, name, qty, price FROM order_items WHERE order_id IN (${ids.map(() => '?').join(',')}) ORDER BY id`
  ).all(...ids);
  const byOrder = new Map();
  items.forEach((i) => {
    if (!byOrder.has(i.order_id)) byOrder.set(i.order_id, []);
    byOrder.get(i.order_id).push(i);
  });
  return rows.map((r) => toApi(r, byOrder.get(r.id) || [], now));
}

/** Active orders plus the 20 most recent deliveries, optionally filtered by status / brand. */
function listOrders(db, { status, brandId, now = Date.now() } = {}) {
  const where = [];
  const params = [];
  if (status) {
    where.push('o.status = ?');
    params.push(status);
  } else {
    where.push(`(o.status != 'delivered' OR o.id IN
      (SELECT id FROM orders WHERE status = 'delivered' ORDER BY delivered_at DESC LIMIT 20))`);
  }
  if (brandId) {
    where.push('o.brand_id = ?');
    params.push(brandId);
  }
  const rows = db.prepare(`${SELECT} WHERE ${where.join(' AND ')} ORDER BY o.created_at, o.id LIMIT 500`).all(...params);
  return hydrate(db, rows, now);
}

function getOrder(db, id, now = Date.now()) {
  const row = getRow(db, id);
  if (!row) throw new HttpError(404, 'Order not found');
  return hydrate(db, [row], now)[0];
}

function logEvent(db, orderId, status, now, note = null) {
  db.prepare('INSERT INTO order_events (order_id, status, note, at) VALUES (?, ?, ?, ?)').run(orderId, status, note, now);
}

/** Moves an order into `next` and writes the matching timestamp + audit event. Call inside a transaction. */
function applyTransition(db, row, next, now, extra = {}) {
  const column = TIME_COLUMN[next];
  const sets = ['status = ?', `${column} = ?`];
  const values = [next, now];
  if (extra.etaTotalS != null) {
    sets.push('eta_total_s = ?');
    values.push(extra.etaTotalS);
  }
  db.prepare(`UPDATE orders SET ${sets.join(', ')} WHERE id = ?`).run(...values, row.id);
  logEvent(db, row.id, next, now, extra.note);
}

/** Advances an order exactly one step along the lifecycle. */
function advanceOrder(db, id, now, baseUrl) {
  return tx(db, () => {
    const row = getRow(db, id);
    if (!row) throw new HttpError(404, 'Order not found');
    const next = STATUSES[STATUSES.indexOf(row.status) + 1];
    if (!next) throw new HttpError(409, 'Order is already delivered');

    const extra = {};
    if (next === 'out_for_delivery') {
      if (!row.courier_id) throw new HttpError(409, 'Assign a courier before dispatching this order');
      const stopsAhead = db.prepare(
        "SELECT COUNT(*) AS n FROM orders WHERE courier_id = ? AND status = 'out_for_delivery'"
      ).get(row.courier_id).n;
      extra.etaTotalS = transitSeconds(haversineKm(cfg.KITCHEN, row), stopsAhead);
    }
    applyTransition(db, row, next, now, extra);
    sms.queueForStatus(db, { ...row, status: next }, now, baseUrl, extra.etaTotalS);
    return { from: row.status, to: next, order: getOrder(db, id, now) };
  });
}

function jitter() {
  return (Math.random() * 2 - 1) * 0.008;
}

/** Validates and inserts a new order in status "received". */
function createOrder(db, input, now, baseUrl) {
  const v = new Validator();
  const brandId = v.int(input.brandId, 'brandId', { min: 1 });
  const zoneId = v.int(input.zoneId, 'zoneId', { min: 1 });
  const customerName = v.text(input.customerName, 'customerName', { min: 2, max: 60 });
  const address = v.text(input.address, 'address', { min: 5, max: 160 });
  const phone = v.phone(input.phone, 'phone');
  if (!Array.isArray(input.items) || input.items.length < 1 || input.items.length > 20) {
    v.fail('items', 'must list between 1 and 20 menu items');
  }
  v.assert();

  const brand = db.prepare('SELECT id FROM brands WHERE id = ?').get(brandId);
  if (!brand) v.fail('brandId', 'unknown brand');
  const zone = db.prepare('SELECT * FROM zones WHERE id = ?').get(zoneId);
  if (!zone) v.fail('zoneId', 'unknown delivery sector');
  v.assert();

  // Merge duplicate lines and check each item belongs to the chosen brand (multi-brand integrity).
  const wanted = new Map();
  input.items.forEach((line, i) => {
    const menuItemId = v.int(line && line.menuItemId, `items[${i}].menuItemId`, { min: 1 });
    const qty = v.int(line && line.qty, `items[${i}].qty`, { min: 1, max: 20 });
    if (menuItemId && qty) wanted.set(menuItemId, (wanted.get(menuItemId) || 0) + qty);
  });
  v.assert();

  const menuRow = db.prepare('SELECT id, name, price FROM menu_items WHERE id = ? AND brand_id = ?');
  const lines = [...wanted].map(([menuItemId, qty]) => {
    const item = menuRow.get(menuItemId, brandId);
    if (!item) v.fail('items', `menu item ${menuItemId} does not belong to this brand`);
    return item && { menuItemId, name: item.name, price: item.price, qty };
  });
  v.assert();
  if (lines.reduce((n, l) => n + l.qty, 0) > 30) throw new HttpError(400, 'Validation failed', { items: 'too many items (max 30)' });

  let lat = zone.lat + jitter();
  let lng = zone.lng + jitter();
  if (input.lat !== undefined || input.lng !== undefined) {
    lat = v.number(input.lat, 'lat', { min: -90, max: 90 });
    lng = v.number(input.lng, 'lng', { min: -180, max: 180 });
    v.assert();
    if (haversineKm(zone, { lat, lng }) > 6) v.fail('lat', 'location is outside the chosen delivery sector');
    v.assert();
  }

  const total = lines.reduce((sum, l) => sum + l.price * l.qty, 0);
  const token = crypto.randomBytes(9).toString('base64url');

  const id = tx(db, () => {
    const result = db.prepare(`INSERT INTO orders
      (brand_id, customer_name, phone, address, zone_id, lat, lng, status, total, tracking_token, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'received', ?, ?, ?)`)
      .run(brandId, customerName, phone, address, zoneId, lat, lng, total, token, now);
    const orderId = Number(result.lastInsertRowid);
    const insertItem = db.prepare('INSERT INTO order_items (order_id, menu_item_id, name, qty, price) VALUES (?, ?, ?, ?, ?)');
    lines.forEach((l) => insertItem.run(orderId, l.menuItemId, l.name, l.qty, l.price));
    logEvent(db, orderId, 'received', now);
    sms.queueForStatus(db, { ...getRow(db, orderId) }, now, baseUrl);
    return orderId;
  });
  return getOrder(db, id, now);
}

const SAMPLE_CUSTOMERS = ['Ishaan Rao', 'Ananya Bose', 'Dev Malhotra', 'Zoya Farooqui', 'Harsh Vora', 'Neha Pillai', 'Yash Kapoor', 'Isha Reddy'];

/** Creates a random realistic order, used by the "Simulate incoming order" button. */
function createSimulatedOrder(db, now, baseUrl) {
  const pick = (list) => list[Math.floor(Math.random() * list.length)];
  const brand = pick(db.prepare('SELECT id FROM brands').all());
  const zone = pick(db.prepare('SELECT id, name FROM zones').all());
  const menu = db.prepare('SELECT id FROM menu_items WHERE brand_id = ?').all(brand.id);
  const lineCount = 1 + Math.floor(Math.random() * 3);
  const items = Array.from({ length: lineCount }, () => ({ menuItemId: pick(menu).id, qty: 1 + Math.floor(Math.random() * 2) }));
  return createOrder(db, {
    brandId: brand.id,
    zoneId: zone.id,
    customerName: pick(SAMPLE_CUSTOMERS),
    phone: `+9190${String(10000000 + Math.floor(Math.random() * 89999999))}`,
    address: `Flat ${100 + Math.floor(Math.random() * 400)}, Sample Residency, ${zone.name.split(' - ')[1]}`,
    items,
  }, now, baseUrl);
}

/** Public, customer-safe view of an order for the tracking page (no phone, no courier id). */
function trackingView(db, token, now = Date.now()) {
  const row = getRowByToken(db, token);
  if (!row) throw new HttpError(404, 'Tracking link not found');
  const order = hydrate(db, [row], now)[0];
  const events = db.prepare('SELECT status, at FROM order_events WHERE order_id = ? ORDER BY at, id').all(row.id);
  const assigned = Boolean(row.courier_id) && (row.status === 'packed' || row.status === 'out_for_delivery');
  return {
    orderId: order.id,
    brand: order.brand,
    brandColor: order.brandColor,
    status: order.status,
    statusLabel: order.statusLabel,
    steps: STATUSES.map((s) => ({ key: s, label: STATUS_LABELS[s], at: events.find((e) => e.status === s)?.at ?? null })),
    courierName: assigned || row.status === 'delivered' ? row.courier_name : null,
    courierAssigned: assigned,
    items: order.items,
    total: order.total,
    zoneName: order.zoneName,
    etaSeconds: order.etaSeconds,
    etaTotalSeconds: order.etaTotalSeconds,
    timeScale: cfg.TIME_SCALE,
    outAt: order.outAt,
    serverNow: now,
    orderIdForStream: row.id,
  };
}

module.exports = {
  STATUSES, getRow, getRowByToken, hydrate, listOrders, getOrder, createOrder, createSimulatedOrder,
  advanceOrder, applyTransition, logEvent, trackingView, etaSeconds,
};
