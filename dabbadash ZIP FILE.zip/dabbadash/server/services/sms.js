'use strict';

/**
 * Customer SMS tracking-link simulator. No real SMS is sent: every message is stored in
 * sms_log and shown in the manager dashboard so the notification flow can be demonstrated.
 */

function trackingLink(baseUrl, token) {
  return `${baseUrl}/track.html?t=${encodeURIComponent(token)}`;
}

const TEMPLATES = {
  received: (o) => `DabbaDash: We received your ${o.brand_name} order #${o.id}.`,
  in_kitchen: (o) => `DabbaDash: Your ${o.brand_name} order #${o.id} is being cooked now.`,
  packed: (o) => `DabbaDash: Order #${o.id} is packed and waiting for a courier.`,
  assigned: (o) => `DabbaDash: ${o.courier_name} will pick up your order #${o.id} shortly.`,
  out_for_delivery: (o, ctx) =>
    `DabbaDash: Order #${o.id} is out for delivery with ${o.courier_name}. ETA ${ctx.etaMinutes} min.`,
  delivered: (o) => `DabbaDash: Order #${o.id} was delivered. Enjoy your meal!`,
  resend: (o) => `DabbaDash: Track your ${o.brand_name} order #${o.id} live.`,
};

/** Stores one simulated SMS. `row` is a joined order row (needs brand_name, courier_name, tracking_token). */
function queue(db, row, kind, now, baseUrl, ctx = {}) {
  const link = trackingLink(baseUrl, row.tracking_token);
  const body = `${TEMPLATES[kind](row, ctx)} Track live: ${link}`;
  db.prepare('INSERT INTO sms_log (order_id, phone, body, link, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(row.id, row.phone, body, link, now);
  return { body, link };
}

function queueForStatus(db, row, now, baseUrl, etaSeconds) {
  const ctx = { etaMinutes: etaSeconds ? Math.max(1, Math.ceil(etaSeconds / 60)) : null };
  return queue(db, row, row.status, now, baseUrl, ctx);
}

function maskPhone(phone) {
  return phone.length > 4 ? `${'*'.repeat(phone.length - 4)}${phone.slice(-4)}` : phone;
}

function list(db, limit = 30) {
  return db.prepare(`SELECT s.id, s.order_id, s.phone, s.body, s.link, s.created_at, b.name AS brand_name
    FROM sms_log s JOIN orders o ON o.id = s.order_id JOIN brands b ON b.id = o.brand_id
    ORDER BY s.id DESC LIMIT ?`).all(limit).map((r) => ({
    id: r.id,
    orderId: r.order_id,
    brand: r.brand_name,
    to: maskPhone(r.phone),
    body: r.body,
    link: r.link,
    createdAt: r.created_at,
  }));
}

module.exports = { queue, queueForStatus, list, trackingLink, maskPhone };
