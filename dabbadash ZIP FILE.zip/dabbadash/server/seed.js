'use strict';

const crypto = require('node:crypto');
const { tx } = require('./db');
const { transitSeconds } = require('./eta');
const { haversineKm } = require('./geo');
const { KITCHEN } = require('./config');

const BRANDS = [
  { id: 1, name: 'Biryani Box', color: '#b45309', tagline: 'Dum biryani, delivered hot' },
  { id: 2, name: 'Burger Den', color: '#b91c1c', tagline: 'Stacked, smashed, sorted' },
  { id: 3, name: 'Chai Point', color: '#0f766e', tagline: 'Cutting chai and bites' },
];

const MENU = [
  [1, 'Hyderabadi Chicken Dum Biryani', 249],
  [1, 'Mutton Biryani', 329],
  [1, 'Paneer Biryani', 219],
  [1, 'Veg Biryani', 179],
  [1, 'Egg Biryani', 199],
  [1, 'Mirchi Ka Salan', 59],
  [1, 'Double Ka Meetha', 79],
  [2, 'Crispy Chicken Burger', 159],
  [2, 'Veggie Burger', 119],
  [2, 'Paneer Tikka Burger', 139],
  [2, 'Double Patty Burger', 219],
  [2, 'Peri Peri Fries', 99],
  [2, 'Classic Fries', 79],
  [2, 'Chocolate Shake', 129],
  [3, 'Irani Chai', 39],
  [3, 'Masala Chai', 35],
  [3, 'Filter Coffee', 49],
  [3, 'Osmania Biscuits', 29],
  [3, 'Samosa', 30],
  [3, 'Bun Maska', 45],
];

// Four delivery sectors across Hyderabad, all >3 km apart so batches never span sectors by accident.
const ZONES = [
  { id: 1, code: 'A', name: 'Sector A - Gachibowli', lat: 17.4401, lng: 78.3489 },
  { id: 2, code: 'B', name: 'Sector B - Madhapur', lat: 17.4486, lng: 78.3908 },
  { id: 3, code: 'C', name: 'Sector C - Kondapur', lat: 17.47, lng: 78.356 },
  { id: 4, code: 'D', name: 'Sector D - Banjara Hills', lat: 17.4126, lng: 78.4482 },
];

const COURIERS = [
  { id: 1, name: 'Ramesh', vehicle: 'scooter', capacity: 3, zone: 2 },
  { id: 2, name: 'Suresh', vehicle: 'bike', capacity: 4, zone: 1 },
  { id: 3, name: 'Anita', vehicle: 'scooter', capacity: 3, zone: 3 },
  { id: 4, name: 'Imran', vehicle: 'bicycle', capacity: 2, zone: 2 },
  { id: 5, name: 'Priya', vehicle: 'scooter', capacity: 3, zone: 4 },
  { id: 6, name: 'Kiran', vehicle: 'bike', capacity: 4, zone: 1 },
];

/*
 * 15 simulated active orders. Times are "minutes ago". Order #104 matches the demo script
 * in the problem brief (Burger Den: 2 burgers + fries, currently in the kitchen, sector B).
 */
const ORDERS = [
  { id: 101, brand: 1, name: 'Aarav Reddy', zone: 1, status: 'delivered', courier: 2, t: { c: 62, k: 58, p: 45, o: 44, d: 30 }, items: [['Hyderabadi Chicken Dum Biryani', 2], ['Mirchi Ka Salan', 1]] },
  { id: 102, brand: 3, name: 'Sneha Rao', zone: 3, status: 'delivered', courier: 3, t: { c: 55, k: 52, p: 44, o: 43, d: 33 }, items: [['Irani Chai', 2], ['Osmania Biscuits', 1]] },
  { id: 103, brand: 2, name: 'Vikram Singh', zone: 2, status: 'out_for_delivery', courier: 4, t: { c: 40, k: 37, p: 26, o: 6 }, items: [['Double Patty Burger', 1], ['Peri Peri Fries', 1]] },
  { id: 104, brand: 2, name: 'Rohan Gupta', zone: 2, status: 'in_kitchen', t: { c: 12, k: 8 }, items: [['Crispy Chicken Burger', 2], ['Classic Fries', 1]] },
  { id: 105, brand: 1, name: 'Meera Nair', zone: 2, status: 'in_kitchen', t: { c: 34, k: 30 }, items: [['Mutton Biryani', 1], ['Double Ka Meetha', 1]] },
  { id: 106, brand: 3, name: 'Rahul Verma', zone: 4, status: 'in_kitchen', t: { c: 28, k: 24 }, items: [['Masala Chai', 3], ['Samosa', 2]] },
  { id: 107, brand: 2, name: 'Divya Menon', zone: 1, status: 'received', t: { c: 3 }, items: [['Veggie Burger', 1], ['Classic Fries', 1], ['Chocolate Shake', 1]] },
  { id: 108, brand: 1, name: 'Kiran Kumar', zone: 3, status: 'received', t: { c: 2 }, items: [['Paneer Biryani', 2]] },
  { id: 109, brand: 3, name: 'Pooja Shah', zone: 2, status: 'received', t: { c: 1 }, items: [['Filter Coffee', 2], ['Bun Maska', 2]] },
  { id: 110, brand: 1, name: 'Arjun Das', zone: 1, status: 'packed', t: { c: 30, k: 24, p: 4 }, items: [['Hyderabadi Chicken Dum Biryani', 1]] },
  { id: 111, brand: 2, name: 'Tanvi Joshi', zone: 1, status: 'packed', t: { c: 26, k: 21, p: 3 }, items: [['Paneer Tikka Burger', 1], ['Peri Peri Fries', 1]] },
  { id: 112, brand: 3, name: 'Sameer Khan', zone: 2, status: 'packed', courier: 1, t: { c: 22, k: 18, p: 2 }, items: [['Masala Chai', 2], ['Samosa', 4]] },
  { id: 113, brand: 3, name: 'Lakshmi Iyer', zone: 3, status: 'out_for_delivery', courier: 3, t: { c: 25, k: 22, p: 14, o: 6 }, items: [['Filter Coffee', 1], ['Bun Maska', 1]] },
  { id: 114, brand: 1, name: 'Farhan Ali', zone: 4, status: 'out_for_delivery', courier: 5, t: { c: 33, k: 30, p: 18, o: 9 }, items: [['Veg Biryani', 1], ['Mirchi Ka Salan', 1]] },
  { id: 115, brand: 2, name: 'Nisha Patel', zone: 3, status: 'delivered', courier: 6, t: { c: 70, k: 66, p: 52, o: 50, d: 38 }, items: [['Paneer Tikka Burger', 2]] },
];

const STREETS = ['Lotus Residency', 'Green Park Apartments', 'Skyline Heights', 'Orchid Villas', 'Maple Court'];

/** Deterministic pseudo-random offset in degrees (about +/-0.9 km) so seeded pins spread out. */
function jitter(id, k) {
  const x = Math.sin(id * 12.9898 + k * 78.233) * 43758.5453;
  return ((x - Math.floor(x)) * 2 - 1) * 0.008;
}

function seedReference(db) {
  const count = db.prepare('SELECT COUNT(*) AS n FROM brands').get().n;
  if (count > 0) return false;
  tx(db, () => {
    const brand = db.prepare('INSERT INTO brands (id, name, color, tagline) VALUES (?, ?, ?, ?)');
    BRANDS.forEach((b) => brand.run(b.id, b.name, b.color, b.tagline));
    const menu = db.prepare('INSERT INTO menu_items (brand_id, name, price) VALUES (?, ?, ?)');
    MENU.forEach(([brandId, name, price]) => menu.run(brandId, name, price));
    const zone = db.prepare('INSERT INTO zones (id, code, name, lat, lng) VALUES (?, ?, ?, ?, ?)');
    ZONES.forEach((z) => zone.run(z.id, z.code, z.name, z.lat, z.lng));
    const courier = db.prepare(
      'INSERT INTO couriers (id, name, vehicle, capacity, zone_id, lat, lng, active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
    );
    COURIERS.forEach((c) => {
      const z = ZONES.find((zone) => zone.id === c.zone);
      courier.run(c.id, c.name, c.vehicle, c.capacity, c.zone, z.lat + jitter(c.id, 1) / 4, z.lng + jitter(c.id, 2) / 4);
    });
  });
  return true;
}

/** Replaces all orders with the 15-order demo data set. `now` is epoch milliseconds. */
function seedOrders(db, now = Date.now()) {
  tx(db, () => {
    db.exec('DELETE FROM sms_log; DELETE FROM order_events; DELETE FROM order_items; DELETE FROM orders;');
    try {
      db.exec("DELETE FROM sqlite_sequence WHERE name = 'orders'");
    } catch {
      /* sqlite_sequence does not exist until the first AUTOINCREMENT insert */
    }

    const priceOf = db.prepare('SELECT id, price FROM menu_items WHERE brand_id = ? AND name = ?');
    const insertOrder = db.prepare(`INSERT INTO orders
      (id, brand_id, customer_name, phone, address, zone_id, lat, lng, status, courier_id, total, tracking_token,
       created_at, kitchen_at, packed_at, out_at, delivered_at, eta_total_s)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    const insertItem = db.prepare('INSERT INTO order_items (order_id, menu_item_id, name, qty, price) VALUES (?, ?, ?, ?, ?)');
    const insertEvent = db.prepare('INSERT INTO order_events (order_id, status, note, at) VALUES (?, ?, NULL, ?)');

    ORDERS.forEach((o) => {
      const zone = ZONES.find((z) => z.id === o.zone);
      const lat = zone.lat + jitter(o.id, 3);
      const lng = zone.lng + jitter(o.id, 4);
      const ago = (m) => (m == null ? null : now - m * 60 * 1000);
      const lines = o.items.map(([name, qty]) => {
        const row = priceOf.get(o.brand, name);
        if (!row) throw new Error(`Seed data error: unknown menu item "${name}"`);
        return { menuItemId: row.id, name, qty, price: row.price };
      });
      const total = lines.reduce((sum, l) => sum + l.price * l.qty, 0);
      const etaTotal = o.t.o != null ? transitSeconds(haversineKm(KITCHEN, { lat, lng }), 0) : null;
      const phone = `+9198${String(76543000 + o.id).padStart(8, '0')}`;
      const street = STREETS[o.id % STREETS.length];

      insertOrder.run(
        o.id, o.brand, o.name, phone, `Flat ${100 + (o.id % 9) * 10 + 2}, ${street}, ${zone.name.split(' - ')[1]}`,
        o.zone, lat, lng, o.status, o.courier ?? null, total, crypto.randomBytes(9).toString('base64url'),
        ago(o.t.c), ago(o.t.k), ago(o.t.p), ago(o.t.o), ago(o.t.d), etaTotal
      );
      lines.forEach((l) => insertItem.run(o.id, l.menuItemId, l.name, l.qty, l.price));
      [['received', o.t.c], ['in_kitchen', o.t.k], ['packed', o.t.p], ['out_for_delivery', o.t.o], ['delivered', o.t.d]]
        .filter(([, minutes]) => minutes != null)
        .forEach(([status, minutes]) => insertEvent.run(o.id, status, ago(minutes)));
    });
  });
}

module.exports = { seedReference, seedOrders, ZONES, BRANDS };
