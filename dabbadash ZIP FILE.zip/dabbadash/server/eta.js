'use strict';

const { AVG_SPEED_KMH, STOP_MINUTES, MIN_TRANSIT_SECONDS } = require('./config');

/**
 * Simulated transit time in seconds for a drop that is `km` from the kitchen
 * and is the (stopIndex + 1)-th stop on the courier's trip.
 */
function transitSeconds(km, stopIndex = 0) {
  const minutes = (km / AVG_SPEED_KMH) * 60 + STOP_MINUTES * (stopIndex + 1);
  return Math.max(MIN_TRANSIT_SECONDS, Math.round(minutes * 60));
}

module.exports = { transitSeconds };
