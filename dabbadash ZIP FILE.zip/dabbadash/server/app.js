'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const cfg = require('./config');
const { openDb } = require('./db');
const { HttpError } = require('./errors');
const { Validator, idParam } = require('./validate');
const auth = require('./auth');
const { Hub } = require('./realtime');
const { seedReference, seedOrders } = require('./seed');
const orders = require('./services/orders');
const couriers = require('./services/couriers');
const { buildBatches } = require('./services/batcher');
const { computeMetrics } = require('./services/metrics');
const payout = require('./services/payout');
const sms = require('./services/sms');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const COOKIE_NAME = 'dd_session';
const DEFAULT_PASSWORD = 'Dabba@123';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self' https://unpkg.com",
    "style-src 'self' 'unsafe-inline' https://unpkg.com",
    "img-src 'self' data: https://*.tile.openstreetmap.org https://unpkg.com",
    "connect-src 'self'",
    "frame-ancestors 'none'",
    "base-uri 'none'",
    "form-action 'self'",
  ].join('; '),
};

const SSE_HANDLED = Symbol('sse-handled');
const reply = (status, data, headers = {}) => ({ status, data, headers });

function parseCookies(header = '') {
  const out = {};
  header.split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  });
  return out;
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const type = (req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    const length = Number(req.headers['content-length'] || 0);
    if (!length && req.headers['transfer-encoding'] === undefined) return resolve({});
    if (type !== 'application/json') return reject(new HttpError(415, 'Content-Type must be application/json'));
    if (length > cfg.MAX_BODY_BYTES) return reject(new HttpError(413, 'Request body too large'));
    let size = 0;
    const chunks = [];
    let tooBig = false;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > cfg.MAX_BODY_BYTES) tooBig = true;
      else chunks.push(chunk);
    });
    req.on('end', () => {
      if (tooBig) return reject(new HttpError(413, 'Request body too large'));
      if (!chunks.length) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
          return reject(new HttpError(400, 'Request body must be a JSON object'));
        }
        return resolve(parsed);
      } catch {
        return reject(new HttpError(400, 'Request body is not valid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, status, data, headers = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(body);
}

/**
 * Builds the HTTP server, database and realtime hub.
 * @param options.dbPath      SQLite file or ':memory:'
 * @param options.baseUrl     public URL used inside SMS tracking links
 * @param options.managerPassword initial password for the seeded `manager` user
 * @param options.quiet       suppress request logging
 */
function createApp(options = {}) {
  const db = openDb(options.dbPath || ':memory:');
  const hub = new Hub();
  const limiter = new auth.LoginLimiter();
  const clock = options.clock || (() => Date.now());
  const managerPassword = options.managerPassword || process.env.MANAGER_PASSWORD || DEFAULT_PASSWORD;
  const usingDefaultPassword = managerPassword === DEFAULT_PASSWORD;

  seedReference(db);
  if (db.prepare('SELECT COUNT(*) AS n FROM orders').get().n === 0) seedOrders(db, clock());
  auth.ensureUser(db, 'manager', managerPassword, 'manager', clock());
  auth.purgeExpiredSessions(db, clock());
  const purgeTimer = setInterval(() => auth.purgeExpiredSessions(db, clock()), 60 * 60 * 1000);
  purgeTimer.unref();

  const routes = [];
  function route(method, pattern, opts, handler) {
    const keys = [];
    const regex = new RegExp(
      '^' + pattern.replace(/:([a-zA-Z]+)/g, (_, key) => { keys.push(key); return '([^/]+)'; }) + '/?$'
    );
    routes.push({ method, regex, keys, auth: opts.auth !== false, handler });
  }

  const notify = (type, orderIds = []) => hub.broadcast({ type, orderIds });
  let server;
  const baseUrl = () => options.baseUrl || process.env.BASE_URL || `http://localhost:${server.address()?.port ?? 3000}`;

  // ---------------------------------------------------------------- auth
  route('POST', '/api/auth/login', { auth: false }, (ctx) => {
    const v = new Validator();
    const username = v.text(ctx.body.username, 'username', { min: 1, max: 64 });
    const password = typeof ctx.body.password === 'string' && ctx.body.password.length >= 1 && ctx.body.password.length <= 200
      ? ctx.body.password : v.fail('password', 'is required');
    v.assert();

    const key = `${ctx.req.socket.remoteAddress}|${username.toLowerCase()}`;
    const wait = limiter.retryAfter(key, ctx.now);
    if (wait > 0) return reply(429, { error: `Too many failed attempts. Try again in ${wait}s.` }, { 'Retry-After': String(wait) });

    const user = auth.authenticate(db, username, password);
    if (!user) {
      limiter.recordFailure(key, ctx.now);
      throw new HttpError(401, 'Invalid username or password');
    }
    limiter.reset(key);
    const session = auth.createSession(db, user.id, ctx.now);
    const secure = ctx.req.headers['x-forwarded-proto'] === 'https' || options.secureCookies ? '; Secure' : '';
    return reply(200, { user }, {
      'Set-Cookie': `${COOKIE_NAME}=${session.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${session.maxAgeSeconds}${secure}`,
    });
  });

  route('POST', '/api/auth/logout', { auth: false }, (ctx) => {
    auth.destroySession(db, ctx.cookies[COOKIE_NAME]);
    return reply(200, { ok: true }, { 'Set-Cookie': `${COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0` });
  });

  route('GET', '/api/auth/me', {}, (ctx) => ({ user: ctx.user }));
  route('GET', '/api/health', { auth: false }, () => ({ status: 'ok', time: new Date().toISOString() }));

  // ---------------------------------------------------------------- reference data
  route('GET', '/api/state', {}, (ctx) => ({
    user: ctx.user,
    kitchen: cfg.KITCHEN,
    statuses: cfg.STATUSES.map((key) => ({ key, label: cfg.STATUS_LABELS[key] })),
    brands: db.prepare('SELECT id, name, color, tagline FROM brands ORDER BY id').all(),
    zones: db.prepare('SELECT id, code, name, lat, lng FROM zones ORDER BY id').all(),
    menu: db.prepare('SELECT id, brand_id AS brandId, name, price FROM menu_items ORDER BY brand_id, id').all(),
    bottleneckMinutes: cfg.BOTTLENECK_MINUTES,
    clusterRadiusKm: cfg.CLUSTER_RADIUS_KM,
    timeScale: cfg.TIME_SCALE,
  }));

  // ---------------------------------------------------------------- orders
  route('GET', '/api/orders', {}, (ctx) => {
    const status = ctx.query.get('status');
    if (status && !cfg.STATUSES.includes(status)) throw new HttpError(400, 'Unknown status filter');
    const brand = ctx.query.get('brandId');
    const list = orders.listOrders(db, { status, brandId: brand ? idParam(brand, 'brandId') : null, now: ctx.now });
    return { serverNow: ctx.now, orders: couriers.attachRecommendations(db, list, ctx.now) };
  });

  route('POST', '/api/orders', {}, (ctx) => {
    const order = orders.createOrder(db, ctx.body, ctx.now, baseUrl());
    notify('order-created', [order.id]);
    return reply(201, { order });
  });

  route('POST', '/api/orders/simulate', {}, (ctx) => {
    const order = orders.createSimulatedOrder(db, ctx.now, baseUrl());
    notify('order-created', [order.id]);
    return reply(201, { order });
  });

  route('GET', '/api/orders/:id', {}, (ctx) => ({ order: orders.getOrder(db, idParam(ctx.params.id), ctx.now) }));

  route('POST', '/api/orders/:id/advance', {}, (ctx) => {
    const id = idParam(ctx.params.id);
    const result = orders.advanceOrder(db, id, ctx.now, baseUrl());
    const recommendation = result.to === 'packed' ? (couriers.recommendFor(db, id, ctx.now)[0] || null) : null;
    notify('order-advanced', [id]);
    return { ...result, recommendation };
  });

  route('GET', '/api/orders/:id/recommendations', {}, (ctx) => ({
    recommendations: couriers.recommendFor(db, idParam(ctx.params.id), ctx.now),
  }));

  route('POST', '/api/orders/:id/assign', {}, (ctx) => {
    const id = idParam(ctx.params.id);
    const v = new Validator();
    const courierId = v.int(ctx.body.courierId, 'courierId', { min: 1 });
    v.assert();
    const order = couriers.assignOrder(db, id, courierId, ctx.now, baseUrl());
    notify('order-assigned', [id]);
    return { order };
  });

  route('POST', '/api/orders/:id/unassign', {}, (ctx) => {
    const id = idParam(ctx.params.id);
    const order = couriers.unassignOrder(db, id, ctx.now);
    notify('order-unassigned', [id]);
    return { order };
  });

  route('POST', '/api/orders/:id/sms', {}, (ctx) => {
    const id = idParam(ctx.params.id);
    const row = orders.getRow(db, id);
    if (!row) throw new HttpError(404, 'Order not found');
    const message = sms.queue(db, row, 'resend', ctx.now, baseUrl());
    return reply(201, { message });
  });

  // ---------------------------------------------------------------- couriers, batches, payouts
  route('GET', '/api/couriers', {}, (ctx) => ({ couriers: couriers.listCouriers(db, ctx.now) }));

  route('POST', '/api/couriers/:id/dispatch', {}, (ctx) => {
    const id = idParam(ctx.params.id);
    const orderIds = couriers.dispatchCourier(db, id, ctx.now, baseUrl());
    notify('courier-dispatched', orderIds);
    return { dispatchedOrderIds: orderIds };
  });

  route('GET', '/api/couriers/:id/payout', {}, (ctx) => couriers.payoutEstimate(db, idParam(ctx.params.id), ctx.now));

  route('POST', '/api/payout/estimate', {}, (ctx) => {
    const v = new Validator();
    const distanceKm = v.number(ctx.body.distanceKm, 'distanceKm', { min: 0, max: 100 });
    const stops = v.int(ctx.body.stops, 'stops', { min: 1, max: 8 });
    const peak = ctx.body.peak === undefined ? null : v.bool(ctx.body.peak, 'peak');
    v.assert();
    const backlog = computeMetrics(db, ctx.now).inKitchen;
    return { payout: payout.calculate({ distanceKm, stops, now: ctx.now, kitchenBacklog: backlog, forcePeak: peak }) };
  });

  route('GET', '/api/batches', {}, (ctx) => {
    const context = couriers.loadCourierContext(db, ctx.now);
    return { radiusKm: cfg.CLUSTER_RADIUS_KM, batches: buildBatches(db, ctx.now, context, couriers.rankCouriers) };
  });

  route('POST', '/api/batches/assign', {}, (ctx) => {
    const v = new Validator();
    const courierId = v.int(ctx.body.courierId, 'courierId', { min: 1 });
    v.assert();
    const ids = couriers.assignBatch(db, ctx.body.orderIds, courierId, ctx.now, baseUrl());
    notify('batch-assigned', ids);
    return { assignedOrderIds: ids };
  });

  // ---------------------------------------------------------------- metrics, sms, demo
  route('GET', '/api/metrics', {}, (ctx) => computeMetrics(db, ctx.now));
  route('GET', '/api/sms', {}, () => ({ messages: sms.list(db, 40) }));

  route('POST', '/api/demo/reset', {}, (ctx) => {
    seedOrders(db, ctx.now);
    notify('reset', db.prepare('SELECT id FROM orders').all().map((r) => r.id));
    return { ok: true };
  });

  // ---------------------------------------------------------------- realtime streams
  route('GET', '/api/stream', {}, (ctx) => {
    hub.subscribe(ctx.req, ctx.res, null);
    return SSE_HANDLED;
  });

  // ---------------------------------------------------------------- public customer tracking
  route('GET', '/api/track/:token', { auth: false }, (ctx) => {
    const view = orders.trackingView(db, ctx.params.token, ctx.now);
    delete view.orderIdForStream;
    return view;
  });

  route('GET', '/api/track/:token/stream', { auth: false }, (ctx) => {
    const row = orders.getRowByToken(db, ctx.params.token);
    if (!row) throw new HttpError(404, 'Tracking link not found');
    hub.subscribe(ctx.req, ctx.res, row.id);
    return SSE_HANDLED;
  });

  // ---------------------------------------------------------------- request pipeline
  async function handleApi(req, res, url) {
    const method = req.method;
    let pathMatched = false;
    for (const r of routes) {
      const m = r.regex.exec(url.pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method) continue;

      const now = clock();
      const cookies = parseCookies(req.headers.cookie);
      const user = auth.getSessionUser(db, cookies[COOKIE_NAME], now);
      if (r.auth && !user) throw new HttpError(401, 'Authentication required');

      if (method !== 'GET') {
        // CSRF defence in depth on top of SameSite=Strict: reject cross-origin browser requests.
        const origin = req.headers.origin;
        if (origin && new URL(origin).host !== req.headers.host) throw new HttpError(403, 'Cross-origin request blocked');
      }

      const params = {};
      r.keys.forEach((key, i) => { params[key] = decodeURIComponent(m[i + 1]); });
      const body = method === 'GET' ? {} : await readJsonBody(req);
      const result = await r.handler({ req, res, params, query: url.searchParams, body, user, cookies, now });
      if (result === SSE_HANDLED) return;
      if (result && result.status && 'data' in result) return sendJson(res, result.status, result.data, result.headers);
      return sendJson(res, 200, result);
    }
    throw new HttpError(pathMatched ? 405 : 404, pathMatched ? 'Method not allowed' : 'Endpoint not found');
  }

  function serveStatic(req, res, url) {
    if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed');
    let rel;
    try {
      rel = decodeURIComponent(url.pathname);
    } catch {
      throw new HttpError(400, 'Bad request path');
    }
    if (rel.includes('\0')) throw new HttpError(400, 'Bad request path');
    if (rel === '/') rel = '/index.html';
    const full = path.join(PUBLIC_DIR, rel);
    if (!full.startsWith(PUBLIC_DIR + path.sep)) throw new HttpError(404, 'Not found');
    fs.readFile(full, (err, data) => {
      if (err) return sendJson(res, 404, { error: 'Not found' });
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
        'Content-Length': data.length,
        'Cache-Control': 'no-cache',
      });
      return res.end(req.method === 'HEAD' ? undefined : data);
    });
  }

  server = http.createServer((req, res) => {
    Object.entries(SECURITY_HEADERS).forEach(([k, v]) => res.setHeader(k, v));
    const started = Date.now();
    if (!options.quiet) {
      res.on('finish', () => console.log(`${req.method} ${req.url.split('?')[0]} ${res.statusCode} ${Date.now() - started}ms`));
    }
    Promise.resolve()
      .then(() => {
        const url = new URL(req.url, 'http://localhost');
        return url.pathname.startsWith('/api/') ? handleApi(req, res, url) : serveStatic(req, res, url);
      })
      .catch((err) => {
        if (res.headersSent) return res.end();
        if (err instanceof HttpError) return sendJson(res, err.status, { error: err.message, details: err.details });
        console.error('Unhandled error:', err);
        return sendJson(res, 500, { error: 'Internal server error' });
      });
  });

  function close() {
    clearInterval(purgeTimer);
    hub.close();
    return new Promise((resolve) => {
      server.close(() => {
        try { db.close(); } catch { /* already closed */ }
        resolve();
      });
      server.closeAllConnections();
    });
  }

  return { server, db, hub, close, usingDefaultPassword };
}

module.exports = { createApp };
