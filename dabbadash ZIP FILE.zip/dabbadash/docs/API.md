# REST API

All bodies are JSON (`Content-Type: application/json`). Errors look like
`{ "error": "message", "details": { "field": "reason" } }`.

Status codes: `400` validation, `401` not signed in, `403` cross-origin write, `404` not found,
`405` wrong method, `409` business-rule conflict, `413` body too large, `415` wrong content type,
`429` too many login attempts.

## Public

| Method | Path | Description |
|---|---|---|
| GET | `/api/health` | Liveness check |
| POST | `/api/auth/login` | `{username, password}` sets the session cookie |
| POST | `/api/auth/logout` | Destroys the session |
| GET | `/api/track/:token` | Customer-safe order view (status, steps, courier name, ETA) |
| GET | `/api/track/:token/stream` | SSE stream for that one order |

## Manager (session cookie required)

| Method | Path | Description |
|---|---|---|
| GET | `/api/auth/me` | Current user |
| GET | `/api/state` | Brands, zones, menu, kitchen location, thresholds |
| GET | `/api/stream` | SSE stream of all changes |
| GET | `/api/orders?status=&brandId=` | Active orders plus 20 latest deliveries; packed orders include a courier `recommendation` |
| POST | `/api/orders` | Create an order `{brandId, zoneId, customerName, phone, address, items:[{menuItemId, qty}]}` |
| POST | `/api/orders/simulate` | Create a random realistic order |
| GET | `/api/orders/:id` | One order |
| POST | `/api/orders/:id/advance` | Move to the next status (returns the courier recommendation when it becomes packed) |
| GET | `/api/orders/:id/recommendations` | Ranked couriers for an order |
| POST | `/api/orders/:id/assign` | `{courierId}` (packed orders only; capacity enforced) |
| POST | `/api/orders/:id/unassign` | Remove the pending courier |
| POST | `/api/orders/:id/sms` | Generate a simulated SMS tracking link |
| GET | `/api/couriers` | Roster with load, status, live position, trip payout |
| POST | `/api/couriers/:id/dispatch` | Send the courier out with all their packed orders on one route |
| GET | `/api/couriers/:id/payout` | Current trip payout estimate |
| POST | `/api/payout/estimate` | `{distanceKm, stops, peak?}` earnings calculator |
| GET | `/api/batches` | Hyperlocal batches with distance saved and a suggested courier |
| POST | `/api/batches/assign` | `{orderIds, courierId}` atomic batch assignment |
| GET | `/api/metrics` | Live KPIs |
| GET | `/api/sms` | Simulated SMS log |
| POST | `/api/demo/reset` | Restore the 15-order demo data |
