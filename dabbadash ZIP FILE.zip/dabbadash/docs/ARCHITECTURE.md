# Architecture

## Tiers

```
 Browser (presentation)              Node.js server (application)                SQLite (data)
 ┌──────────────────────┐   HTTPS   ┌─────────────────────────────────┐        ┌──────────────┐
 │ index.html  (manager)│ ───────►  │ app.js     routing, auth, CSRF  │        │ brands       │
 │ track.html  (customer)│  REST    │ services/  business rules       │ ─────► │ menu_items   │
 │ login.html            │ ◄─────── │   orders    state machine       │  SQL   │ zones        │
 │ js/ ES modules        │   SSE    │   couriers  ranking, capacity   │        │ couriers     │
 └──────────────────────┘           │   batcher   sector clustering   │        │ orders       │
                                    │   payout, metrics, sms          │        │ order_items  │
                                    │ realtime.js SSE hub             │        │ order_events │
                                    └─────────────────────────────────┘        │ sms_log      │
                                                                               │ users        │
                                                                               │ sessions     │
                                                                               └──────────────┘
```

Separation of concerns:

- **Presentation** (`public/`) holds no business rules. It renders what the API returns and calls endpoints.
  Modules: `api` (transport), `state` (data store + change detection), `realtime`, one module per view, `actions`.
- **Application** (`server/`) owns every rule. HTTP concerns (`app.js`) are separate from domain logic (`services/`).
- **Data** (`server/db.js`) owns the schema. Multi-step changes run inside transactions (`tx`).

## Order lifecycle

```
received ──► in_kitchen ──► packed ──► out_for_delivery ──► delivered
                              │  ▲
              assign courier ─┘  └─ unassign          (dispatch requires an assigned courier)
```

Rules enforced in `services/orders.js` and `services/couriers.js`:

- One step at a time; no skipping or going backwards.
- A courier can only be assigned to a **packed** order.
- Dispatch (`packed -> out_for_delivery`) requires an assigned courier.
- A courier already out on a delivery cannot take new orders.
- Vehicle capacity (bicycle 2, scooter 3, bike 4) is checked on single and batch assignment; batch assignment is atomic.

## Hyperlocal Sector Clustering Heuristic

`clusterOrders(points, {radiusKm = 2.5, maxSize = 4})` in `services/batcher.js`:

1. Sort unbatched orders oldest first.
2. Take the oldest as a **seed**.
3. Add the nearest orders within `radiusKm` (haversine) of the seed, up to `maxSize`.
4. Remove them from the pool and repeat.

Oldest-first seeding means the longest-waiting order always anchors a batch. Complexity is O(n²), fine for one
kitchen's live queue. `buildBatches` then reports, for each cluster, the nearest-neighbour route length versus
the sum of separate trips (distance saved), and a courier who can carry every packed order in it.

## Courier recommendation

For an order, candidate couriers are those at the kitchen (not out on a delivery) with free capacity.
Lower score is better:

```
score = distance(courier home base, drop)
      + 0.4 km  x orders already carried
      - 1.5 km  if the courier already carries an order within the cluster radius
```

The last term makes the system prefer extending an existing run over starting a new one.

## Real-time synchronisation

- `GET /api/stream` (managers) and `GET /api/track/:token/stream` (one customer) are Server-Sent Events.
  Every mutation broadcasts to the affected order's subscribers; a customer's stream can never see other orders.
- Every client also polls every 3 seconds, so a proxy that buffers SSE cannot break the dashboard.
- Timers and the bottleneck flash are advanced locally every second using the server clock offset.

## ETA and delivery simulation

`transitSeconds(km, stopIndex)` = distance / 18 km/h + 2 min per stop, minimum 5 minutes. When a courier is
dispatched with several orders, stops are ordered by a nearest-neighbour route and each order gets its own ETA.
The customer page counts down locally and moves the scooter in proportion to `1 - remaining / total`.
`TIME_SCALE` speeds this up for demos.

## Data model (summary)

`orders` links to `brands`, `zones` and `couriers`, and stores one timestamp per stage (`created_at`, `kitchen_at`,
`packed_at`, `out_at`, `delivered_at`), which gives prep-time KPIs without extra tables. `order_items` snapshots
name and price at order time. `order_events` is an audit trail. `sms_log` holds simulated messages. `sessions`
stores only token hashes.

## Testing strategy

| File | Level | What it covers |
|---|---|---|
| `tests/auth.test.js` | unit | hashing, salts, sessions, expiry, rate limiter |
| `tests/dispatch.test.js` | unit + service | clustering, batches, recommendation, capacity, atomic batch assignment, dispatch routing, payouts |
| `tests/orders.test.js` | service | seed data, lifecycle, validation, brand integrity, bottleneck, KPIs, tracking privacy, ETA |
| `tests/api.test.js` | integration (real HTTP) | auth, rate limit, full demo flow, validation, SQL-injection strings, CSRF/size limits, security headers, path traversal, SSE |
