# DabbaDash: LastMile Bite Battle

A hyperlocal delivery management and order-tracking dashboard for cloud kitchens that run several
virtual brands from one commissary kitchen.

**Architecture:** 3-tier. A static modular frontend (`public/`) talks to a Node.js REST API
(`server/`) that persists to SQLite. Live updates use Server-Sent Events with a 3-second polling fallback.

**Zero runtime dependencies.** The server uses only Node's built-in modules (`http`, `crypto`,
`node:sqlite`, `node:test`). There is nothing to `npm install`.

## Quick start

Requires **Node.js 22.13 or newer**.

```bash
cd dabbadash
npm start
# open http://localhost:3000
```

Sign in with `manager` / `Dabba@123`. Set the `MANAGER_PASSWORD` environment variable to use your own password.
The database (`data/dabbadash.db`) is created and seeded on first start. Run `npm run reset-db` to start fresh.

Run the automated tests (35 tests: unit, service and real-HTTP integration):

```bash
npm test
```

### Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | HTTP port |
| `DB_PATH` | `data/dabbadash.db` | SQLite file |
| `MANAGER_PASSWORD` | `Dabba@123` | Password for the seeded `manager` user (a warning is logged if you keep the default) |
| `BASE_URL` | `http://localhost:<port>` | Public URL placed inside SMS tracking links |
| `TIME_SCALE` | `1` | Demo helper: `5` makes simulated deliveries run 5x faster |

## 2-minute demo script (matches the problem brief)

1. Sign in. The **Kitchen Board** shows 15 seeded orders from 3 brands in 5 columns. Orders #105 and #106 flash red because they have been in the kitchen for more than 20 minutes.
2. Open **Customer tracking view** on order **#104** (Burger Den: 2 burgers + fries) in a second window or phone.
3. On #104 click **Mark packed**. A toast recommends **Ramesh (Sector B)**. Click **Assign Ramesh**.
4. The customer window updates instantly: *"Courier Assigned - Ramesh is picking up your food!"*
5. Open the **Dispatch** tab. Click **Dispatch** on Ramesh. The customer page now shows a live countdown and the scooter moving along the track.
6. In the Dispatch tab the **Hyperlocal batches** panel shows the two Sector A orders (#110, #111) grouped into one trip, saving 44% distance. Assign the batch to the suggested courier in one click.
7. Click **Mark delivered**. The customer page flips to *Delivered*.
8. Check the **Sector Map** and **SMS Log** tabs. Try **Simulate incoming order** and the **Rider payout calculator**.

## Requirement traceability

| Brief requirement | Where it lives |
|---|---|
| Multi-brand order aggregation feed | Kitchen Board with brand filter chips (`public/js/board.js`); orders and menu items carry `brand_id` (`server/db.js`) |
| 5-state lifecycle stepper | `STATUSES` in `server/config.js`; state machine in `services/orders.js` (`advanceOrder`) and customer stepper in `public/js/track.js` |
| Delivery rider dispatch console | Dispatch tab (`public/js/dispatch.js`); ranking, capacity and assignment in `services/couriers.js` |
| Hyperlocal delivery radius batcher | `clusterOrders()` / `buildBatches()` in `services/batcher.js` (2.5 km radius, greedy, oldest-first) |
| Customer tracking mock-up (animated vehicle + ETA countdown) | `public/track.html`, `public/js/track.js`, `GET /api/track/:token` |
| Cloud kitchen performance metrics | KPI bar (`public/js/kpis.js`), `services/metrics.js` |
| Stretch: interactive sector map | `public/js/map.js` (Leaflet; falls back to an offline SVG map if the CDN is unreachable) |
| Stretch: kitchen bottleneck alert (>20 min, flashing red) | `isBottleneck()` in `services/orders.js`; CSS `is-bottleneck` flash (disabled for reduced-motion users) |
| Stretch: rider payout & trip calculator | `services/payout.js`, payout calculator panel and per-courier trip payout |
| Stretch: SMS tracking link simulator | `services/sms.js`, SMS Log tab; a message is generated on every status change |
| Suggested stack: Node/Express + SQLite + REST + realtime | Node HTTP server, `node:sqlite`, REST under `/api`, SSE plus 3 s polling |
| Seed data: 3 brands, 20 items, 6 couriers, 4 sectors, 15 orders | `server/seed.js` (asserted by a test) |

Design note: the brief suggests React + TypeScript + Express. This project deliberately uses
framework-free ES modules and Node's built-in HTTP server so it runs anywhere with no install step.
The 3-tier architecture, REST API, SQLite database and real-time sync that the brief asks for are all present.

## Security

- Passwords hashed with scrypt and a per-user random salt; constant-time comparison; equal cost for unknown users
- Sessions: random 256-bit tokens, only the SHA-256 is stored; `HttpOnly`, `SameSite=Strict` cookie; 8 h expiry; logout destroys the session
- Failed-login rate limiting (5 per minute per IP and username, `429` + `Retry-After`)
- All SQL is parameterised; dynamic column names come from a fixed allow-list
- Server-side validation of every input (types, ranges, length, brand/menu integrity) with per-field error messages
- Origin check on state-changing requests, JSON-only bodies, 100 KB body limit
- Security headers (CSP, `nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`); path-traversal-safe static serving
- Frontend never uses `innerHTML`; all server text is rendered via `textContent`
- Customer tracking uses an unguessable 72-bit token and exposes no phone number or internal ids

## Known limitations (by design for a demo)

- Delivery progress is **simulated** from a distance/speed model; there is no live GPS.
- SMS messages are **simulated** and stored in the database; nothing is sent.
- The login rate limiter is in-memory, so it assumes a single server process.
- The Leaflet map needs internet access for the library and tiles; without it the offline SVG map is shown.

See `docs/ARCHITECTURE.md` and `docs/API.md` for details.
