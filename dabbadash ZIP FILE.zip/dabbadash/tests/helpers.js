'use strict';

const { openDb } = require('../server/db');
const { seedReference, seedOrders } = require('../server/seed');

/** A fresh in-memory database seeded with the 15-order demo data, with a fixed "now". */
function freshDb(now = Date.now()) {
  const db = openDb(':memory:');
  seedReference(db);
  seedOrders(db, now);
  return db;
}

const BASE_URL = 'http://localhost:3000';

module.exports = { freshDb, BASE_URL };
