'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server/app');

/** Boots the real HTTP server on a random port with an in-memory database. */
async function start() {
  const app = createApp({ dbPath: ':memory:', quiet: true, managerPassword: 'TestPass#1' });
  await new Promise((resolve) => app.server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  let cookie = '';

  const call = async (method, path, body, { headers = {}, auth = true } = {}) => {
    const response = await fetch(base + path, {
      method,
      headers: {
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(auth && cookie ? { Cookie: cookie } : {}),
        ...headers,
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await response.text();
    let data = null;
    try { data = JSON.parse(text); } catch { data = text; }
    return { status: response.status, data, headers: response.headers };
  };

  const login = async () => {
    const res = await call('POST', '/api/auth/login', { username: 'manager', password: 'TestPass#1' }, { auth: false });
    cookie = res.headers.getSetCookie()[0].split(';')[0];
    return res;
  };
  return { app, base, call, login };
}

test('API requires authentication for dashboard data but not for health or tracking', async (t) => {
  const { app, call } = await start();
  t.after(() => app.close());
  assert.equal((await call('GET', '/api/orders')).status, 401);
  assert.equal((await call('POST', '/api/orders/104/advance', {})).status, 401);
  assert.equal((await call('GET', '/api/health')).status, 200);
  assert.equal((await call('GET', '/api/track/not-a-real-token')).status, 404);
});

test('login: wrong password is rejected, session cookie is HttpOnly + SameSite=Strict', async (t) => {
  const { app, call } = await start();
  t.after(() => app.close());
  const bad = await call('POST', '/api/auth/login', { username: 'manager', password: 'nope' }, { auth: false });
  assert.equal(bad.status, 401);
  const good = await call('POST', '/api/auth/login', { username: 'manager', password: 'TestPass#1' }, { auth: false });
  assert.equal(good.status, 200);
  const cookie = good.headers.getSetCookie()[0];
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);
  assert.equal(JSON.stringify(good.data).includes('TestPass'), false);
});

test('login is rate limited after repeated failures', async (t) => {
  const { app, call } = await start();
  t.after(() => app.close());
  let last;
  for (let i = 0; i < 6; i += 1) {
    last = await call('POST', '/api/auth/login', { username: 'manager', password: `bad${i}` }, { auth: false });
  }
  assert.equal(last.status, 429);
  assert.ok(last.headers.get('retry-after'));
});

test('full demo flow: pack #104 -> recommendation -> assign -> dispatch -> customer sees live updates', async (t) => {
  const { app, call, login } = await start();
  t.after(() => app.close());
  await login();

  const list = await call('GET', '/api/orders');
  assert.equal(list.status, 200);
  const o104 = list.data.orders.find((o) => o.id === 104);
  assert.equal(o104.status, 'in_kitchen');
  assert.equal(o104.brand, 'Burger Den');

  // Customer view before packing.
  let track = await call('GET', `/api/track/${o104.trackingToken}`, undefined, { auth: false });
  assert.equal(track.data.status, 'in_kitchen');

  // Kitchen manager clicks "Mark packed".
  const packed = await call('POST', '/api/orders/104/advance', {});
  assert.equal(packed.data.to, 'packed');
  assert.equal(packed.data.recommendation.name, 'Ramesh');

  // Assign the recommended courier; the customer view now shows the pickup message state.
  const assigned = await call('POST', '/api/orders/104/assign', { courierId: packed.data.recommendation.courierId });
  assert.equal(assigned.status, 200);
  track = await call('GET', `/api/track/${o104.trackingToken}`, undefined, { auth: false });
  assert.equal(track.data.status, 'packed');
  assert.equal(track.data.courierAssigned, true);
  assert.equal(track.data.courierName, 'Ramesh');

  // Dispatch Ramesh: both of his packed orders (#112 and #104) go out together.
  const dispatched = await call('POST', '/api/couriers/1/dispatch', {});
  assert.deepEqual(dispatched.data.dispatchedOrderIds.sort(), [104, 112]);
  track = await call('GET', `/api/track/${o104.trackingToken}`, undefined, { auth: false });
  assert.equal(track.data.status, 'out_for_delivery');
  assert.ok(track.data.etaSeconds > 0);
  assert.equal(JSON.stringify(track.data).includes('phone'), false);

  // Mark delivered.
  const delivered = await call('POST', '/api/orders/104/advance', {});
  assert.equal(delivered.data.to, 'delivered');

  const metrics = await call('GET', '/api/metrics');
  assert.equal(metrics.data.delivered, 4);
});

test('validation errors return 400 with field details; unknown ids return 404; bad ids return 400', async (t) => {
  const { app, call, login } = await start();
  t.after(() => app.close());
  await login();
  const bad = await call('POST', '/api/orders', { brandId: 1 });
  assert.equal(bad.status, 400);
  assert.ok(bad.data.details.customerName);
  assert.equal((await call('POST', '/api/orders/99999/advance', {})).status, 404);
  assert.equal((await call('POST', '/api/orders/abc/advance', {})).status, 400);
  assert.equal((await call('POST', '/api/orders/104/assign', { courierId: 'x' })).status, 400);
  assert.equal((await call('GET', '/api/orders?status=bogus')).status, 400);
  assert.equal((await call('DELETE', '/api/orders')).status, 405);
  assert.equal((await call('GET', '/api/nothing')).status, 404);
});

test('SQL injection strings are treated as data', async (t) => {
  const { app, call, login } = await start();
  t.after(() => app.close());
  await login();
  const res = await call('POST', '/api/orders', {
    brandId: 1, zoneId: 1, customerName: "Robert'); DROP TABLE orders;--", phone: '9876543210',
    address: '1 Injection Road, Gachibowli', items: [{ menuItemId: 1, qty: 1 }],
  });
  assert.equal(res.status, 201);
  assert.equal(res.data.order.customerName, "Robert'); DROP TABLE orders;--");
  assert.equal((await call('GET', '/api/orders')).status, 200);
});

test('security: cross-origin writes, wrong content type and oversized bodies are rejected', async (t) => {
  const { app, call, login } = await start();
  t.after(() => app.close());
  await login();
  const cross = await call('POST', '/api/orders/simulate', {}, { headers: { Origin: 'https://evil.example' } });
  assert.equal(cross.status, 403);
  const wrongType = await call('POST', '/api/orders/simulate', undefined, { headers: { 'Content-Type': 'text/plain' } });
  assert.ok([415, 201].includes(wrongType.status));
  const huge = await call('POST', '/api/orders', { customerName: 'x'.repeat(200_000) });
  assert.equal(huge.status, 413);
});

test('static files: security headers set and path traversal blocked', async (t) => {
  const { app, base } = await start();
  t.after(() => app.close());
  const home = await fetch(`${base}/`);
  assert.equal(home.status, 200);
  assert.equal(home.headers.get('x-content-type-options'), 'nosniff');
  assert.match(home.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(home.headers.get('x-frame-options'), 'DENY');
  for (const bad of ['/..%2f..%2fpackage.json', '/%2e%2e/server/db.js', '/..%2fserver%2fapp.js']) {
    const res = await fetch(base + bad);
    assert.equal(res.status, 404, `${bad} must not be served`);
  }
  assert.equal((await fetch(`${base}/js/main.js`)).status, 200);
});

test('server-sent events: tracking stream receives an update when the order changes', async (t) => {
  const { app, base, call, login } = await start();
  t.after(() => app.close());
  await login();
  const token = (await call('GET', '/api/orders')).data.orders.find((o) => o.id === 104).trackingToken;

  const controller = new AbortController();
  const stream = await fetch(`${base}/api/track/${token}/stream`, { signal: controller.signal });
  assert.equal(stream.headers.get('content-type').startsWith('text/event-stream'), true);
  const reader = stream.body.getReader();
  const decoder = new TextDecoder();
  let received = '';

  const waitFor = async (needle) => {
    const deadline = Date.now() + 3000;
    while (!received.includes(needle) && Date.now() < deadline) {
      const { value, done } = await reader.read();
      if (done) break;
      received += decoder.decode(value);
    }
    return received.includes(needle);
  };

  assert.ok(await waitFor('event: hello'));
  await call('POST', '/api/orders/104/advance', {});
  assert.ok(await waitFor('event: update'), 'subscriber should be notified immediately');
  controller.abort();
});
