'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const orders = require('../server/services/orders');
const couriers = require('../server/services/couriers');
const metrics = require('../server/services/metrics');
const { freshDb, BASE_URL } = require('./helpers');

const NOW = Date.now();

test('seed data matches the problem brief (3 brands, 20 items, 6 couriers, 4 sectors, 15 orders)', () => {
  const db = freshDb(NOW);
  const count = (t) => db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
  assert.equal(count('brands'), 3);
  assert.equal(count('menu_items'), 20);
  assert.equal(count('couriers'), 6);
  assert.equal(count('zones'), 4);
  assert.equal(count('orders'), 15);
});

test('order lifecycle advances one step at a time through all 5 states', () => {
  const db = freshDb(NOW);
  const order = orders.createOrder(db, {
    brandId: 2, zoneId: 2, customerName: 'Test Customer', phone: '+919999999999',
    address: '12 Test Street, Madhapur', items: [{ menuItemId: 8, qty: 1 }],
  }, NOW, BASE_URL);
  assert.equal(order.status, 'received');

  assert.equal(orders.advanceOrder(db, order.id, NOW + 1000, BASE_URL).to, 'in_kitchen');
  assert.equal(orders.advanceOrder(db, order.id, NOW + 2000, BASE_URL).to, 'packed');

  // Cannot go out for delivery without a courier.
  assert.throws(() => orders.advanceOrder(db, order.id, NOW + 3000, BASE_URL), /Assign a courier/);

  couriers.assignOrder(db, order.id, 1, NOW + 3000, BASE_URL);
  assert.equal(orders.advanceOrder(db, order.id, NOW + 4000, BASE_URL).to, 'out_for_delivery');
  assert.equal(orders.advanceOrder(db, order.id, NOW + 5000, BASE_URL).to, 'delivered');
  assert.throws(() => orders.advanceOrder(db, order.id, NOW + 6000, BASE_URL), /already delivered/);
});

test('each status change writes a timestamp, an audit event and a simulated SMS', () => {
  const db = freshDb(NOW);
  orders.advanceOrder(db, 104, NOW, BASE_URL); // in_kitchen -> packed
  const row = db.prepare('SELECT packed_at FROM orders WHERE id = 104').get();
  assert.equal(row.packed_at, NOW);
  const events = db.prepare("SELECT COUNT(*) AS n FROM order_events WHERE order_id = 104 AND status = 'packed'").get().n;
  assert.equal(events, 1);
  const sms = db.prepare('SELECT body FROM sms_log WHERE order_id = 104').all();
  assert.equal(sms.length, 1);
  assert.match(sms[0].body, /\/track\.html\?t=/);
});

test('multi-brand integrity: items must belong to the chosen brand', () => {
  const db = freshDb(NOW);
  assert.throws(() => orders.createOrder(db, {
    brandId: 1, zoneId: 1, customerName: 'Mixed Up', phone: '9876543210', address: '1 Main Road, Gachibowli',
    items: [{ menuItemId: 8, qty: 1 }], // item 8 belongs to Burger Den, not Biryani Box
  }, NOW, BASE_URL), /Validation failed/);
});

test('order validation reports every bad field and rejects markup', () => {
  const db = freshDb(NOW);
  try {
    orders.createOrder(db, { brandId: 'x', zoneId: 1, customerName: '<script>', phone: '12', address: 'abc', items: [] }, NOW, BASE_URL);
    assert.fail('expected a validation error');
  } catch (err) {
    assert.equal(err.status, 400);
    for (const field of ['brandId', 'customerName', 'phone', 'address', 'items']) {
      assert.ok(err.details[field], `expected an error for ${field}`);
    }
  }
});

test('bottleneck flag: only orders in the kitchen for more than 20 minutes', () => {
  const db = freshDb(NOW);
  const byId = Object.fromEntries(orders.listOrders(db, { now: NOW }).map((o) => [o.id, o]));
  assert.equal(byId[105].bottleneck, true); // 30 min in kitchen
  assert.equal(byId[106].bottleneck, true); // 24 min in kitchen
  assert.equal(byId[104].bottleneck, false); // 8 min in kitchen
  assert.equal(byId[107].bottleneck, false); // only received
  assert.equal(metrics.computeMetrics(db, NOW).bottlenecks, 2);
});

test('KPIs reflect the live queue', () => {
  const db = freshDb(NOW);
  const m = metrics.computeMetrics(db, NOW);
  assert.equal(m.activeOrders, 12);
  assert.equal(m.inKitchen, 6);
  assert.equal(m.pendingDispatch, 2);
  assert.equal(m.dispatched, 3);
  assert.ok(m.avgPrepMinutes > 0);
});

test('customer tracking view hides private data and shows courier assignment', () => {
  const db = freshDb(NOW);
  const token = db.prepare('SELECT tracking_token FROM orders WHERE id = 112').get().tracking_token;
  const view = orders.trackingView(db, token, NOW);
  assert.equal(view.status, 'packed');
  assert.equal(view.courierAssigned, true);
  assert.equal(view.courierName, 'Ramesh');
  assert.equal(JSON.stringify(view).includes('9198'), false, 'phone number must not leak');
  assert.throws(() => orders.trackingView(db, 'does-not-exist', NOW), /not found/);
});

test('countdown: ETA shrinks while out for delivery and reaches zero', () => {
  const db = freshDb(NOW);
  const out = orders.listOrders(db, { status: 'out_for_delivery', now: NOW })[0];
  const later = orders.listOrders(db, { status: 'out_for_delivery', now: NOW + 60_000 }).find((o) => o.id === out.id);
  assert.ok(later.etaSeconds < out.etaSeconds);
  const done = orders.listOrders(db, { status: 'out_for_delivery', now: NOW + 3 * 3600_000 }).find((o) => o.id === out.id);
  assert.equal(done.etaSeconds, 0);
});
