'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const orders = require('../server/services/orders');
const couriers = require('../server/services/couriers');
const payout = require('../server/services/payout');
const { buildBatches, clusterOrders } = require('../server/services/batcher');
const { haversineKm } = require('../server/geo');
const { freshDb, BASE_URL } = require('./helpers');

const NOW = Date.now();

// ---- clustering heuristic (pure function) -------------------------------------------------
test('clustering groups points within the radius and separates distant ones', () => {
  const pts = [
    { id: 1, lat: 17.44, lng: 78.35, createdAt: 1 },
    { id: 2, lat: 17.441, lng: 78.351, createdAt: 2 },
    { id: 3, lat: 17.45, lng: 78.39, createdAt: 3 }, // ~4.5 km away
  ];
  const clusters = clusterOrders(pts, { radiusKm: 2.5, maxSize: 4 });
  assert.equal(clusters.length, 2);
  assert.deepEqual(clusters[0].map((p) => p.id), [1, 2]);
  assert.deepEqual(clusters[1].map((p) => p.id), [3]);
});

test('clustering respects the maximum batch size and anchors on the oldest order', () => {
  const pts = Array.from({ length: 6 }, (_, i) => ({ id: i + 1, lat: 17.44 + i * 0.0001, lng: 78.35, createdAt: 100 - i }));
  const clusters = clusterOrders(pts, { radiusKm: 2.5, maxSize: 4 });
  assert.deepEqual(clusters.map((c) => c.length), [4, 2]);
  assert.equal(clusters[0][0].id, 6); // oldest (createdAt 95)
});

test('every point is placed in exactly one cluster', () => {
  const pts = Array.from({ length: 25 }, (_, i) => ({ id: i + 1, lat: 17.4 + (i % 5) * 0.02, lng: 78.3 + Math.floor(i / 5) * 0.02, createdAt: i }));
  const flat = clusterOrders(pts).flat().map((p) => p.id).sort((a, b) => a - b);
  assert.deepEqual(flat, pts.map((p) => p.id));
});

test('haversine distance is symmetric and plausible', () => {
  const a = { lat: 17.4401, lng: 78.3489 };
  const b = { lat: 17.4486, lng: 78.3908 };
  assert.ok(Math.abs(haversineKm(a, b) - haversineKm(b, a)) < 1e-9);
  assert.ok(haversineKm(a, b) > 4 && haversineKm(a, b) < 5);
  assert.equal(haversineKm(a, a), 0);
});

// ---- batches over the live queue ------------------------------------------------------------
test('live batches: the two packed Sector A orders share one trip and save distance', () => {
  const db = freshDb(NOW);
  const ctx = couriers.loadCourierContext(db, NOW);
  const batches = buildBatches(db, NOW, ctx, couriers.rankCouriers);
  const sectorA = batches.find((b) => b.zoneCode === 'A');
  assert.equal(sectorA.size, 2);
  assert.deepEqual(sectorA.readyOrderIds.sort(), [110, 111]);
  assert.ok(sectorA.savedKm > 0);
  assert.ok(sectorA.suggestedCourier, 'a courier with capacity should be suggested');
});

// ---- courier recommendation & assignment ----------------------------------------------------
test('demo flow: packing #104 recommends Ramesh (Sector B), who already carries a nearby order', () => {
  const db = freshDb(NOW);
  orders.advanceOrder(db, 104, NOW, BASE_URL);
  const best = couriers.recommendFor(db, 104, NOW)[0];
  assert.equal(best.name, 'Ramesh');
  assert.equal(best.zoneCode, 'B');
});

test('couriers who are out on a delivery are never recommended or assignable', () => {
  const db = freshDb(NOW);
  const recommended = couriers.recommendFor(db, 110, NOW).map((r) => r.name);
  assert.equal(recommended.includes('Imran'), false); // out with #103
  assert.throws(() => couriers.assignOrder(db, 110, 4, NOW, BASE_URL), /out on a delivery/);
});

test('vehicle capacity is enforced on single and batch assignment', () => {
  const db = freshDb(NOW);
  // Ramesh's scooter holds 3 and already has #112. Pack two more, then a fourth must fail.
  const make = (n) => Array.from({ length: n }, (_, i) => orders.createOrder(db, {
    brandId: 3, zoneId: 2, customerName: `Cap Test ${i}`, phone: '9876543210', address: '5 Capacity Lane, Madhapur',
    items: [{ menuItemId: 15, qty: 1 }],
  }, NOW, BASE_URL));
  const created = make(3);
  created.forEach((o) => { orders.advanceOrder(db, o.id, NOW, BASE_URL); orders.advanceOrder(db, o.id, NOW, BASE_URL); });
  couriers.assignOrder(db, created[0].id, 1, NOW, BASE_URL);
  couriers.assignOrder(db, created[1].id, 1, NOW, BASE_URL); // now 3/3
  assert.throws(() => couriers.assignOrder(db, created[2].id, 1, NOW, BASE_URL), /at capacity/);
  assert.throws(() => couriers.assignBatch(db, [created[2].id], 1, NOW, BASE_URL), /cannot carry/);
});

test('batch assignment is atomic: one bad order rolls back the whole batch', () => {
  const db = freshDb(NOW);
  assert.throws(() => couriers.assignBatch(db, [110, 107], 2, NOW, BASE_URL), /not packed/); // 107 is only "received"
  const row = db.prepare('SELECT courier_id FROM orders WHERE id = 110').get();
  assert.equal(row.courier_id, null);
});

test('dispatching a courier sends all of their packed orders out on one route with ETAs', () => {
  const db = freshDb(NOW);
  couriers.assignBatch(db, [110, 111], 2, NOW, BASE_URL);
  const sent = couriers.dispatchCourier(db, 2, NOW, BASE_URL);
  assert.equal(sent.length, 2);
  const out = orders.listOrders(db, { status: 'out_for_delivery', now: NOW }).filter((o) => sent.includes(o.id));
  assert.equal(out.length, 2);
  out.forEach((o) => assert.ok(o.etaTotalSeconds >= 300));
  const [first, second] = sent.map((id) => out.find((o) => o.id === id));
  assert.ok(second.etaTotalSeconds >= first.etaTotalSeconds, 'later stops have longer ETAs');
  assert.throws(() => couriers.dispatchCourier(db, 2, NOW, BASE_URL), /no packed orders/);
});

// ---- payouts ---------------------------------------------------------------------------------
test('payout: base + distance + multi-stop bonus, no surge off-peak', () => {
  const p = payout.calculate({ distanceKm: 5, stops: 2, forcePeak: false, kitchenBacklog: 0 });
  assert.equal(p.base, 25);
  assert.equal(p.distancePay, 40);
  assert.equal(p.extraStopPay, 10);
  assert.equal(p.surgePay, 0);
  assert.equal(p.total, 75);
});

test('payout: peak surge multiplies the subtotal and high demand surge applies when backlog is large', () => {
  const peak = payout.calculate({ distanceKm: 5, stops: 1, forcePeak: true });
  assert.equal(peak.surgeMultiplier, 1.3);
  assert.equal(peak.total, 84.5); // (25 + 40) * 1.3
  const demand = payout.calculate({ distanceKm: 5, stops: 1, forcePeak: false, kitchenBacklog: 9 });
  assert.equal(demand.surgeMultiplier, 1.2);
  assert.equal(demand.surgeReason, 'High kitchen demand');
});

test('peak hours are detected in IST', () => {
  const lunchIst = Date.UTC(2026, 0, 5, 7, 30); // 13:00 IST
  const lateIst = Date.UTC(2026, 0, 5, 22, 0); // 03:30 IST next day
  assert.equal(payout.isPeakHour(lunchIst), true);
  assert.equal(payout.isPeakHour(lateIst), false);
});
