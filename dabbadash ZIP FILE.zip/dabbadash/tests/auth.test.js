'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const auth = require('../server/auth');
const { openDb } = require('../server/db');

test('passwords are salted and hashed, never stored in plain text', () => {
  const a = auth.hashPassword('Secret#123');
  const b = auth.hashPassword('Secret#123');
  assert.notEqual(a, b, 'a fresh salt must produce a different hash each time');
  assert.equal(a.includes('Secret#123'), false);
  assert.ok(auth.verifyPassword('Secret#123', a));
  assert.equal(auth.verifyPassword('secret#123', a), false);
  assert.equal(auth.verifyPassword('anything', 'not-a-valid-hash'), false);
});

test('authenticate accepts valid credentials and rejects invalid ones', () => {
  const db = openDb(':memory:');
  auth.ensureUser(db, 'chef', 'Tandoori!9');
  assert.equal(auth.authenticate(db, 'chef', 'Tandoori!9').username, 'chef');
  assert.equal(auth.authenticate(db, 'CHEF', 'Tandoori!9').username, 'chef', 'usernames are case-insensitive');
  assert.equal(auth.authenticate(db, 'chef', 'wrong'), null);
  assert.equal(auth.authenticate(db, 'ghost', 'Tandoori!9'), null);
});

test('sessions store only a token hash, expire, and can be destroyed', () => {
  const db = openDb(':memory:');
  auth.ensureUser(db, 'chef', 'pw');
  const user = auth.authenticate(db, 'chef', 'pw');
  const now = 1_000_000;
  const { token } = auth.createSession(db, user.id, now);

  const stored = db.prepare('SELECT token_hash FROM sessions').get().token_hash;
  assert.notEqual(stored, token, 'raw session token must never be stored');
  assert.equal(auth.getSessionUser(db, token, now + 1000).username, 'chef');
  assert.equal(auth.getSessionUser(db, token, now + 9 * 3600_000), null, 'expired after the TTL');

  const second = auth.createSession(db, user.id, now).token;
  auth.destroySession(db, second);
  assert.equal(auth.getSessionUser(db, second, now), null);
  assert.equal(auth.getSessionUser(db, 'x'.repeat(500), now), null);
});

test('login limiter blocks after repeated failures and recovers after the window', () => {
  const limiter = new auth.LoginLimiter(3, 60_000);
  const key = '1.2.3.4|chef';
  for (let i = 0; i < 3; i += 1) limiter.recordFailure(key, 1000 + i);
  assert.ok(limiter.retryAfter(key, 2000) > 0);
  assert.equal(limiter.retryAfter(key, 1000 + 61_000), 0);
  limiter.recordFailure(key, 100_000);
  limiter.reset(key);
  assert.equal(limiter.retryAfter(key, 100_001), 0);
});
